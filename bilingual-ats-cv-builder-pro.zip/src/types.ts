export type Language = 'en' | 'ar';

export type CvTemplateId = 'classic' | 'executive' | 'sidebar' | 'corporate' | 'compact';

export interface CvTemplateInfo {
  id: CvTemplateId;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  badgeBg: string;
  badgeText: string;
}

export const CV_TEMPLATES: CvTemplateInfo[] = [
  {
    id: 'classic',
    nameAr: 'النموذج الكلاسيكي (Classic ATS)',
    nameEn: 'Classic Clean ATS',
    descriptionAr: 'تصميم رسمي أنيق ومنظم مناسب لكافة أنظمة الفحص الالي ATS',
    descriptionEn: 'Standard high-readability layout ideal for corporate ATS parsers',
    badgeBg: 'bg-emerald-600',
    badgeText: 'text-white',
  },
  {
    id: 'executive',
    nameAr: 'التنفيذي الحديث (Modern Executive)',
    nameEn: 'Modern Executive',
    descriptionAr: 'شريط هيدر دكن ملكي مع لمسات ذهبية وتنسيق قيادي رفيع المستوى',
    descriptionEn: 'Dark navy executive header with gold accents and high-impact hierarchy',
    badgeBg: 'bg-slate-900',
    badgeText: 'text-amber-400',
  },
  {
    id: 'sidebar',
    nameAr: 'الجانبي الإبداعي (Creative Sidebar)',
    nameEn: 'Creative Sidebar',
    descriptionAr: 'تقسيم ثنائي عمودي إبداعي يبرز المهارات والتواصل بلمسات نيلي وزيتي',
    descriptionEn: 'Two-column layout with styled sidebar for skills, contact & credentials',
    badgeBg: 'bg-teal-700',
    badgeText: 'text-teal-100',
  },
  {
    id: 'corporate',
    nameAr: 'الأناقة المؤسساتية (Corporate Elegance)',
    nameEn: 'Corporate Elegance',
    descriptionAr: 'تصميم ملكي راقي بألوان العنابي الداكن وفواصل عناوين مزدوجة فخمة',
    descriptionEn: 'Sophisticated Burgundy layout with centered monogram and double line accents',
    badgeBg: 'bg-rose-900',
    badgeText: 'text-rose-200',
  },
  {
    id: 'compact',
    nameAr: 'التقني المبسط (Tech Compact)',
    nameEn: 'Tech Compact',
    descriptionAr: 'تنسيق عالي الكثافة بألوان السماوي والأزرق الفولاذي مخصص للمهندسين والتقنيين',
    descriptionEn: 'High-density sky blue layout optimized for tech & engineering profiles',
    badgeBg: 'bg-sky-700',
    badgeText: 'text-sky-100',
  },
];


export interface WorkExperience {
  id: string;
  companyEn: string;
  companyAr: string;
  roleEn: string;
  roleAr: string;
  startDate: string;
  endDate: string;
  locationEn: string;
  locationAr: string;
  bulletsEn: string[];
  bulletsAr: string[];
}

export interface Education {
  id: string;
  institutionEn: string;
  institutionAr: string;
  degreeEn: string;
  degreeAr: string;
  startDate: string;
  endDate: string;
  detailsEn?: string;
  detailsAr?: string;
}

export interface Certification {
  id: string;
  titleEn: string;
  titleAr: string;
  issuerEn: string;
  issuerAr: string;
  year?: string;
}

export interface SkillCategory {
  id: string;
  categoryEn: string;
  categoryAr: string;
  skillsEn: string[];
  skillsAr: string[];
}

export interface CandidateProfile {
  fullNameEn: string;
  fullNameAr: string;
  titleEn: string;
  titleAr: string;
  email: string;
  phone: string;
  addressEn: string;
  addressAr: string;
  photoUrl?: string; // Optional for visual mode
  summaryEn: string;
  summaryAr: string;
  experiences: WorkExperience[];
  education: Education[];
  certifications: Certification[];
  skillCategories: SkillCategory[];
  languages: {
    languageEn: string;
    languageAr: string;
    levelEn: string;
    levelAr: string;
  }[];
  politicalRoleEn?: string;
  politicalRoleAr?: string;
}

export interface AtsScoreAnalysis {
  score: number; // 0 - 100
  formattingScore: number;
  keywordScore: number;
  actionVerbScore: number;
  completenessScore: number;
  feedback: {
    type: 'success' | 'warning' | 'info';
    messageEn: string;
    messageAr: string;
  }[];
  missingKeywords: string[];
  strongVerbsFound: string[];
}

export interface TargetJobPosting {
  jobTitle: string;
  company: string;
  jobDescription: string;
}
