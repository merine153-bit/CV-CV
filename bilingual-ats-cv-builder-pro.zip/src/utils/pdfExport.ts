import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export function openPrintWindow(elementId: string, title: string) {
  const element = document.getElementById(elementId);
  if (!element) return;

  try {
    // Primary: Native browser window print
    window.print();
  } catch (e) {
    console.warn('Native window.print() error, using print iframe fallback:', e);
    // Fallback: create a temporary print iframe
    const existingFrame = document.getElementById('print-iframe-worker');
    if (existingFrame) existingFrame.remove();

    const iframe = document.createElement('iframe');
    iframe.id = 'print-iframe-worker';
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (!doc) return;
    const isAr = element.getAttribute('dir') === 'rtl';

    doc.open();
    doc.write(`
      <!DOCTYPE html>
      <html dir="${isAr ? 'rtl' : 'ltr'}">
        <head>
          <title>${title}</title>
          <meta charset="utf-8" />
          <style>
            * { 
              box-sizing: border-box; 
              box-shadow: none !important;
              -webkit-box-shadow: none !important;
            }
            body { 
              background: #ffffff !important; 
              color: #0f172a !important; 
              margin: 0 !important; 
              padding: 20px !important; 
              font-family: 'Cairo', system-ui, -apple-system, sans-serif !important; 
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            #cv-printable-area {
              box-shadow: none !important;
              -webkit-box-shadow: none !important;
              border: none !important;
            }
            @page { size: A4 portrait; margin: 10mm 12mm 20mm 12mm; }
          </style>
        </head>
        <body>
          ${element.outerHTML}
          <script>
            setTimeout(() => {
              window.focus();
              window.print();
            }, 300);
          </script>
        </body>
      </html>
    `);
    doc.close();
  }
}

export async function generateAndDownloadPdf(elementId: string, filename: string): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) return false;

  try {
    const canvas = await html2canvas(element, {
      scale: 2, // High resolution for crisp, sharp text
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: 850, // Fixed width so layout renders as desktop print sheet
      onclone: (clonedDoc) => {
        // 1. Convert all unsupported color functions (oklab, oklch, color-mix, light-dark) in style tags to safe hex fallbacks
        const styleTags = clonedDoc.querySelectorAll('style');
        styleTags.forEach((tag) => {
          if (tag.textContent) {
            let text = tag.textContent;
            let prevText = '';
            while (text !== prevText) {
              prevText = text;
              text = text.replace(/(oklab|oklch|color-mix|light-dark)\([^()]*\)/gi, '#1e293b');
            }
            tag.textContent = text;
          }
        });

        // 2. Format cloned target
        const clonedTarget = clonedDoc.getElementById(elementId);
        if (clonedTarget) {
          clonedTarget.style.position = 'relative';
          clonedTarget.style.width = '800px';
          clonedTarget.style.maxWidth = '800px';
          clonedTarget.style.margin = '0 auto';
          clonedTarget.style.padding = '24px 24px 40px 24px';
          clonedTarget.style.boxSizing = 'border-box';
          clonedTarget.style.backgroundColor = '#ffffff';
          clonedTarget.style.color = '#0f172a';
          clonedTarget.style.boxShadow = 'none';
          clonedTarget.style.borderRadius = '0px';
          clonedTarget.style.border = 'none';

          // Normalize all elements, inline styles, and remove unsupported colors/shadows
          const allElements = Array.from(clonedDoc.querySelectorAll('*')) as HTMLElement[];
          allElements.forEach((el) => {
            el.style.boxShadow = 'none';
            el.style.letterSpacing = 'normal';

            const inlineStyle = el.getAttribute('style');
            if (inlineStyle && /(oklab|oklch|color-mix|light-dark)/i.test(inlineStyle)) {
              let text = inlineStyle;
              let prevText = '';
              while (text !== prevText) {
                prevText = text;
                text = text.replace(/(oklab|oklch|color-mix|light-dark)\([^()]*\)/gi, '#1e293b');
              }
              el.setAttribute('style', text);
            }

            try {
              const comp = window.getComputedStyle(el);
              if (comp.backgroundColor && /(oklab|oklch|color-mix|light-dark)/i.test(comp.backgroundColor)) {
                const hasExplicitStyleBg = el.style.backgroundColor && !/(oklab|oklch|color-mix|light-dark)/i.test(el.style.backgroundColor);
                if (!hasExplicitStyleBg) {
                  const classListStr = el.className || '';
                  if (/bg-slate-800|bg-slate-900|bg-slate-950/i.test(classListStr)) {
                    el.style.backgroundColor = '#1e293b';
                  } else if (/bg-slate-100/i.test(classListStr)) {
                    el.style.backgroundColor = '#f1f5f9';
                  } else if (/bg-slate-50/i.test(classListStr)) {
                    el.style.backgroundColor = '#f8fafc';
                  } else {
                    el.style.backgroundColor = '#ffffff';
                  }
                }
              }

              if (comp.color && /(oklab|oklch|color-mix|light-dark)/i.test(comp.color)) {
                const hasExplicitStyleColor = el.style.color && !/(oklab|oklch|color-mix|light-dark)/i.test(el.style.color);
                if (!hasExplicitStyleColor) {
                  const classListStr = el.className || '';
                  if (/text-(white|slate-100|slate-200|slate-300|amber-300|amber-400|yellow-300)/i.test(classListStr)) {
                    el.style.color = '#f8fafc';
                  } else if (/text-(slate-400|slate-500)/i.test(classListStr)) {
                    el.style.color = '#64748b';
                  } else {
                    const darkParent = el.closest('[style*="#0f172a"], [style*="#1e293b"], .bg-slate-900, .bg-slate-800');
                    if (darkParent) {
                      el.style.color = '#ffffff';
                    } else {
                      el.style.color = '#0f172a';
                    }
                  }
                }
              }

              if (comp.borderColor && /(oklab|oklch|color-mix|light-dark)/i.test(comp.borderColor)) {
                const hasExplicitStyleBorder = el.style.borderColor && !/(oklab|oklch|color-mix|light-dark)/i.test(el.style.borderColor);
                if (!hasExplicitStyleBorder) {
                  const classListStr = el.className || '';
                  if (/border-slate-700|border-slate-800/i.test(classListStr)) {
                    el.style.borderColor = '#334155';
                  } else {
                    el.style.borderColor = '#cbd5e1';
                  }
                }
              }
            } catch (e) {
              // Ignore computed style errors on unattached nodes
            }
          });

          // Normalize inline badge vertical text alignment for canvas export to elevate text inside frames
          const badgeElements = Array.from(clonedDoc.querySelectorAll(
            '.cv-badge, .cv-pill, span.rounded, span.rounded-md, span.rounded-lg, span.rounded-full'
          )) as HTMLElement[];

          badgeElements.forEach((el) => {
            el.style.display = 'inline-block';
            el.style.verticalAlign = 'middle';
            el.style.lineHeight = '1';
            el.style.paddingTop = '1px';
            el.style.paddingBottom = '6px';
            el.style.paddingLeft = '8px';
            el.style.paddingRight = '8px';
            el.style.boxSizing = 'border-box';
            el.style.overflow = 'visible';

            if (!el.getAttribute('data-pdf-elevated')) {
              el.setAttribute('data-pdf-elevated', 'true');
              const content = el.innerHTML;
              el.innerHTML = `<span style="position: relative; top: -3.5px; display: inline-block; line-height: 1; vertical-align: middle;">${content}</span>`;
            }
          });

          // 3. Smart Pagination Calculation:
          // A4 page height at 800px width is 800 * (297 / 210) = 1131.43px
          const PAGE_HEIGHT = 1131.43;
          const BOTTOM_GAP = 70; // Reserved ~70px (3-4 lines of whitespace) at bottom of every page

          const getRelativeTop = (el: HTMLElement) => {
            let top = 0;
            let curr: HTMLElement | null = el;
            while (curr && curr !== clonedTarget) {
              top += curr.offsetTop;
              curr = curr.offsetParent as HTMLElement | null;
            }
            return top;
          };

          const sections = Array.from(clonedTarget.querySelectorAll('.cv-section')) as HTMLElement[];

          sections.forEach((sec) => {
            const h2 = sec.querySelector('h2') as HTMLElement | null;
            const items = Array.from(sec.querySelectorAll('.cv-item')) as HTMLElement[];

            // 1. Prevent Section Header Orphans:
            if (h2) {
              const h2Top = getRelativeTop(h2);
              const h2Height = h2.offsetHeight;
              const h2PageIdx = Math.floor(h2Top / PAGE_HEIGHT);
              const pageUsableEnd = (h2PageIdx + 1) * PAGE_HEIGHT - BOTTOM_GAP;

              const firstItem = items[0];
              const firstItemHeight = firstItem ? firstItem.offsetHeight : 30;
              const minNeededSpace = h2Top + h2Height + Math.min(firstItemHeight, 40) + 10;

              // If h2 starts in/past bottom gap OR header + first item extends into bottom gap
              if (h2Top >= pageUsableEnd || minNeededSpace > pageUsableEnd) {
                const nextPageStart = (h2PageIdx + 1) * PAGE_HEIGHT + 24;
                const pushDist = nextPageStart - h2Top;
                if (pushDist > 0) {
                  const currMargin = parseFloat(window.getComputedStyle(h2).marginTop || '0');
                  h2.style.marginTop = `${currMargin + pushDist}px`;
                }
              }
            }

            // 2. Prevent Individual Item Split across Page Boundary:
            items.forEach((item) => {
              const itemTop = getRelativeTop(item);
              const itemHeight = item.offsetHeight;
              const itemBottom = itemTop + itemHeight;

              const itemPageIdx = Math.floor(itemTop / PAGE_HEIGHT);
              const pageUsableEnd = (itemPageIdx + 1) * PAGE_HEIGHT - BOTTOM_GAP;

              // If item starts in/past bottom gap OR item bottom extends past usable page height
              if (itemTop >= pageUsableEnd || itemBottom > pageUsableEnd) {
                const nextPageStart = (itemPageIdx + 1) * PAGE_HEIGHT + 24;
                const pushDist = nextPageStart - itemTop;
                if (pushDist > 0) {
                  const currMargin = parseFloat(window.getComputedStyle(item).marginTop || '0');
                  item.style.marginTop = `${currMargin + pushDist}px`;
                }
              }
            });
          });
        }
      },
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    
    // Create standard A4 PDF document (210mm x 297mm)
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    // First page
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pdfHeight;

    // Handle overflow for multi-page seamlessly
    while (heightLeft > 5) { // 5mm threshold to prevent empty trailing pages
      position -= pdfHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pdfHeight;
    }

    // Save PDF file
    try {
      pdf.save(filename);
    } catch (saveErr) {
      console.warn('pdf.save failed, using blob link fallback:', saveErr);
      const blob = pdf.output('blob');
      const blobUrl = URL.createObjectURL(blob);
      const downloadLink = document.createElement('a');
      downloadLink.href = blobUrl;
      downloadLink.download = filename;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 3000);
    }

    return true;
  } catch (err) {
    console.error('PDF Canvas Generation failed, opening print dialog:', err);
    openPrintWindow(elementId, filename);
    return false;
  }
}
