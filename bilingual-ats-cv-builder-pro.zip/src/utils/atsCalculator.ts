import { CandidateProfile, AtsScoreAnalysis, Language } from '../types';

const STRONG_ACTION_VERBS_EN = [
  'operate', 'operated', 'monitoring', 'monitored', 'execute', 'executed',
  'manage', 'managed', 'coordinate', 'coordinated', 'spearhead', 'spearheaded',
  'formulate', 'formulated', 'implement', 'implemented', 'optimize', 'optimized',
  'analyze', 'analyzed', 'ensure', 'ensured', 'supervise', 'supervised',
  'lead', 'led', 'maintain', 'maintained', 'perform', 'performed', 'develop', 'developed'
];

const STRONG_ACTION_VERBS_AR = [
  'الإشراف', 'تشغيل', 'مراقبة', 'إدارة', 'تنظيم', 'تنسيق', 'صياغة', 'تطبيق',
  'تحسين', 'تحليل', 'ضمان', 'قيادة', 'تطوير', 'تأمين', 'متابعة', 'معالجة'
];

export function calculateAtsScore(
  profile: CandidateProfile,
  lang: Language = 'ar',
  targetJobDescription?: string
): AtsScoreAnalysis {
  const isEn = lang === 'en';
  const feedback: AtsScoreAnalysis['feedback'] = [];
  const strongVerbsFound: string[] = [];
  const missingKeywords: string[] = [];

  // ----------------------------------------------------
  // 1. SECTION & CONTACT COMPLETENESS SCORE (Weight 25%)
  // ----------------------------------------------------
  let completenessScore = 0;
  
  // Check Contact Information
  const hasName = Boolean((isEn ? profile.fullNameEn : profile.fullNameAr)?.trim() || profile.fullNameEn?.trim() || profile.fullNameAr?.trim());
  const hasEmail = Boolean(profile.email?.trim());
  const hasPhone = Boolean(profile.phone?.trim());
  const hasAddress = Boolean((isEn ? profile.addressEn : profile.addressAr)?.trim() || profile.addressEn?.trim() || profile.addressAr?.trim());

  let contactPoints = 0;
  if (hasName) contactPoints += 8;
  if (hasEmail) contactPoints += 7;
  if (hasPhone) contactPoints += 5;
  if (hasAddress) contactPoints += 5;
  completenessScore += contactPoints;

  // Check Professional Summary
  const summaryText = (isEn ? profile.summaryEn : profile.summaryAr)?.trim() || profile.summaryEn?.trim() || profile.summaryAr?.trim() || '';
  if (summaryText.length > 50) {
    completenessScore += 20;
  } else if (summaryText.length > 0) {
    completenessScore += 10;
  }

  // Check Work Experiences
  const validExperiences = profile.experiences.filter(exp => {
    const role = (isEn ? exp.roleEn : exp.roleAr)?.trim() || exp.roleEn?.trim() || exp.roleAr?.trim();
    const company = (isEn ? exp.companyEn : exp.companyAr)?.trim() || exp.companyEn?.trim() || exp.companyAr?.trim();
    const bullets = (isEn ? exp.bulletsEn : exp.bulletsAr).filter(b => b && b.trim().length > 0);
    return Boolean(role || company || bullets.length > 0);
  });

  if (validExperiences.length >= 2) {
    completenessScore += 25;
  } else if (validExperiences.length === 1) {
    completenessScore += 15;
  }

  // Check Education
  const validEducation = profile.education.filter(edu => {
    const degree = (isEn ? edu.degreeEn : edu.degreeAr)?.trim() || edu.degreeEn?.trim() || edu.degreeAr?.trim();
    const inst = (isEn ? edu.institutionEn : edu.institutionAr)?.trim() || edu.institutionEn?.trim() || edu.institutionAr?.trim();
    return Boolean(degree || inst);
  });
  if (validEducation.length > 0) {
    completenessScore += 15;
  }

  // Check Skills
  const validSkillCategories = profile.skillCategories.filter(cat => {
    const skills = (isEn ? cat.skillsEn : cat.skillsAr).filter(s => s && s.trim().length > 0);
    return skills.length > 0;
  });
  if (validSkillCategories.length > 0) {
    completenessScore += 10;
  }

  // Check Languages
  const validLanguages = profile.languages.filter(l => Boolean((isEn ? l.languageEn : l.languageAr)?.trim()));
  if (validLanguages.length > 0) {
    completenessScore += 5;
  }

  completenessScore = Math.min(100, Math.max(0, completenessScore));

  if (!hasName || !hasEmail || !hasPhone || !hasAddress) {
    feedback.push({
      type: 'warning',
      messageEn: 'Incomplete contact details. Provide name, email, phone, and location.',
      messageAr: 'معلومات الاتصال غير مكتملة. يرجى التأكد من كتابة الاسم والبريد والهاتف والعنوان.'
    });
  } else {
    feedback.push({
      type: 'success',
      messageEn: 'Contact Header Complete: Essential contact details provided in standard format.',
      messageAr: 'رأسية الاتصال مكتملة: جميع بيانات التواصل مكتوبة بالشكل القياسي.'
    });
  }

  if (validExperiences.length === 0) {
    feedback.push({
      type: 'warning',
      messageEn: 'No work experience added. Add work history with achievements to improve score.',
      messageAr: 'لم يتم إضافة خبرات عملية. يفضل إدخال الخبرة لرفع درجة التقيم.'
    });
  }

  // ----------------------------------------------------
  // 2. ACTION VERBS & IMPACT SCORE (Weight 25%)
  // ----------------------------------------------------
  const allBullets = profile.experiences
    .flatMap(exp => (isEn ? exp.bulletsEn : exp.bulletsAr).concat(exp.bulletsEn, exp.bulletsAr))
    .filter(b => b && b.trim().length > 0);

  const fullText = (
    summaryText + ' ' +
    allBullets.join(' ') + ' ' +
    profile.experiences.map(e => `${e.roleEn} ${e.roleAr} ${e.companyEn} ${e.companyAr}`).join(' ')
  ).toLowerCase();

  const combinedVerbs = Array.from(new Set([...STRONG_ACTION_VERBS_AR, ...STRONG_ACTION_VERBS_EN]));

  combinedVerbs.forEach(verb => {
    if (fullText.includes(verb.toLowerCase())) {
      if (!strongVerbsFound.includes(verb)) {
        strongVerbsFound.push(verb);
      }
    }
  });

  let actionVerbScore = 0;
  if (allBullets.length === 0) {
    actionVerbScore = 20;
  } else if (strongVerbsFound.length >= 6) {
    actionVerbScore = 100;
  } else if (strongVerbsFound.length >= 4) {
    actionVerbScore = 85;
  } else if (strongVerbsFound.length >= 2) {
    actionVerbScore = 70;
  } else if (strongVerbsFound.length === 1) {
    actionVerbScore = 50;
  } else {
    actionVerbScore = 30;
  }

  if (strongVerbsFound.length >= 4) {
    feedback.push({
      type: 'success',
      messageEn: `High Impact Action Verbs: Found ${strongVerbsFound.length} strong action verbs (${strongVerbsFound.slice(0, 4).join(', ')}).`,
      messageAr: `أفعال قيادية قوية: تم العثور على ${strongVerbsFound.length} أفعال إنجاز قوية مثل (${strongVerbsFound.slice(0, 4).join('، ')}).`
    });
  } else {
    feedback.push({
      type: 'info',
      messageEn: 'Enhance Impact: Begin experience points with strong action verbs (e.g. Operated, Managed, Optimized, Spearheaded).',
      messageAr: 'تنسيق أفعال الإنجاز: يوصى بزيادة الأفعال التأثيرية مثل (إشراف، تشغيل، قيادة، تنظيم).'
    });
  }

  // ----------------------------------------------------
  // 3. KEYWORD & METRICS SCORE (Weight 30%)
  // ----------------------------------------------------
  let keywordScore = 0;

  // Collect all skills
  const allSkills = profile.skillCategories
    .flatMap(cat => cat.skillsEn.concat(cat.skillsAr))
    .filter(s => s && s.trim().length > 0);

  if (allSkills.length >= 10) {
    keywordScore += 45;
  } else if (allSkills.length >= 5) {
    keywordScore += 30;
  } else if (allSkills.length >= 1) {
    keywordScore += 15;
  }

  // Check for quantifiable metrics (numbers, percentages) in experience bullets
  const numberRegex = /[0-9%٠-٩]+/;
  const bulletsWithMetrics = allBullets.filter(b => numberRegex.test(b));

  if (bulletsWithMetrics.length >= 2) {
    keywordScore += 35;
    feedback.push({
      type: 'success',
      messageEn: `Quantifiable Achievements: Detected ${bulletsWithMetrics.length} points with metrics/percentages.`,
      messageAr: `إنجازات قابلة للمقايسة: تم اكتشاف ${bulletsWithMetrics.length} نقاط تحتوي على أرقام ونسب مئوية.`
    });
  } else if (bulletsWithMetrics.length === 1) {
    keywordScore += 20;
    feedback.push({
      type: 'info',
      messageEn: 'Quantifiable Metrics: Include more numbers and percentages (e.g., 20% increase, 50+ clients).',
      messageAr: 'أرقام وإحصائيات: يفضل إضافة نسب ومؤشرات أرقام في الخبرة (مثل: زيادة بنسبة 20%).'
    });
  } else {
    feedback.push({
      type: 'info',
      messageEn: 'Quantifiable Metrics: Incorporate metrics in experience points to demonstrate impact.',
      messageAr: 'أرقام وإحصائيات: أنظمة ATS تعطي أولوية للمهام المدعومة بأرقام قياسية ونسب إنجاز.'
    });
  }

  // Target Job Description Matching
  if (targetJobDescription && targetJobDescription.trim().length > 15) {
    const cleanJd = targetJobDescription
      .toLowerCase()
      .replace(/[^\w\s\u0600-\u06FF]/gi, ' ');
    const jdWords = Array.from(new Set(cleanJd.split(/\s+/).filter(w => w.length > 3)));

    const matchedWords = jdWords.filter(w => fullText.includes(w));
    const matchRatio = jdWords.length > 0 ? matchedWords.length / jdWords.length : 0;

    const jdMatchScore = Math.min(100, Math.round(matchRatio * 100) + 25);
    keywordScore = Math.round((keywordScore * 0.4) + (jdMatchScore * 0.6));

    feedback.push({
      type: 'info',
      messageEn: `Job Posting Match: ${jdMatchScore}% keyword alignment with the target job posting.`,
      messageAr: `مطابقة الوصف الوظيفي: ${jdMatchScore}% نسبة التوافق مع كلمات الإعلان الوظيفي المستهدف.`
    });
  } else {
    if (summaryText.length > 30 && allSkills.length >= 4) {
      keywordScore += 20;
    }
  }

  keywordScore = Math.min(100, Math.max(0, keywordScore));

  // ----------------------------------------------------
  // 4. FORMATTING & PARSABILITY SCORE (Weight 20%)
  // ----------------------------------------------------
  let formattingScore = 100;

  // Photo check
  if (profile.photoUrl && profile.photoUrl.trim() !== '') {
    formattingScore -= 15;
    feedback.push({
      type: 'warning',
      messageEn: 'Photo Detected: Automated ATS systems recommend text-only resumes to prevent parsing errors.',
      messageAr: 'تم اكتشاف صورة شخصية: أنظمة ATS المباشرة تنصح بإلغاء الصور لتفادي أخطاء القراءة الآلية.'
    });
  } else {
    feedback.push({
      type: 'success',
      messageEn: 'Photo-Free Standard: 100% text layout compliant with ATS scanners.',
      messageAr: 'معيار بدون صور: تنسيق نصي نقي بنسبة 100% متوافق مع كافة أنظمة ATS.'
    });
  }

  // Empty experience bullets penalty
  const experiencesWithNoBullets = validExperiences.filter(exp => {
    const bullets = (isEn ? exp.bulletsAr : exp.bulletsEn).concat(exp.bulletsAr, exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return bullets.length === 0;
  });

  if (experiencesWithNoBullets.length > 0) {
    formattingScore -= 15 * experiencesWithNoBullets.length;
    feedback.push({
      type: 'warning',
      messageEn: 'Empty Experience Details: Add bullet points describing your achievements for each job entry.',
      messageAr: 'خبرات بدون تفاصيل: يرجى كتابة نقاط وإنجازات لكل وظيفة لضمان استخلاص المهام.'
    });
  }

  formattingScore = Math.min(100, Math.max(0, formattingScore));

  // ----------------------------------------------------
  // OVERALL WEIGHTED ATS SCORE (Dynamic Real-time result)
  // ----------------------------------------------------
  const calculatedTotal = Math.round(
    completenessScore * 0.25 +
    keywordScore * 0.30 +
    actionVerbScore * 0.25 +
    formattingScore * 0.20
  );

  const score = Math.min(100, Math.max(0, calculatedTotal));

  return {
    score,
    formattingScore,
    keywordScore,
    actionVerbScore,
    completenessScore,
    feedback,
    missingKeywords,
    strongVerbsFound
  };
}
