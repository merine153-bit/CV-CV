import { CandidateProfile } from '../types';

// Blank initial profile so the user can immediately fill out their own CV
export const blankProfile: CandidateProfile = {
  fullNameEn: "",
  fullNameAr: "",
  titleEn: "",
  titleAr: "",
  email: "",
  phone: "",
  addressEn: "",
  addressAr: "",
  photoUrl: "",
  summaryEn: "",
  summaryAr: "",
  politicalRoleEn: "",
  politicalRoleAr: "",
  experiences: [
    {
      id: "exp-1",
      companyEn: "",
      companyAr: "",
      roleEn: "",
      roleAr: "",
      startDate: "",
      endDate: "",
      locationEn: "",
      locationAr: "",
      bulletsEn: [""],
      bulletsAr: [""]
    }
  ],
  education: [
    {
      id: "edu-1",
      institutionEn: "",
      institutionAr: "",
      degreeEn: "",
      degreeAr: "",
      startDate: "",
      endDate: "",
      detailsEn: "",
      detailsAr: ""
    }
  ],
  certifications: [
    {
      id: "cert-1",
      titleEn: "",
      titleAr: "",
      issuerEn: "",
      issuerAr: "",
      year: ""
    }
  ],
  skillCategories: [
    {
      id: "cat-1",
      categoryEn: "",
      categoryAr: "",
      skillsEn: [],
      skillsAr: []
    }
  ],
  languages: [
    {
      languageEn: "",
      languageAr: "",
      levelEn: "",
      levelAr: ""
    }
  ]
};

// Sample profile for demonstration or reference
export const sampleProfile: CandidateProfile = {
  fullNameEn: "MERINE ABDELILLAH",
  fullNameAr: "مرين عبد الإله",
  titleEn: "Petrochemical Operations Technician & Healthcare Specialist",
  titleAr: "إطار تشغيل في البتروكيماويات والإنتاج وصحة المجتمع",
  email: "merine.abdelillah.31@gmail.com",
  phone: "+213-662505937",
  addressEn: "32 Cté Nouvelle Sidi Maarouf, Oran, Algeria",
  addressAr: "32 حي سيدي معروف الجديد، وهران، الجزائر",
  photoUrl: "",
  summaryEn: "Multi-disciplinary professional with over 6 years of experience spanning Petrochemicals (Sonatrach Methanol Complex), Healthcare Medical Imaging (Radiology, MRI, CT Scan), and Public Institutional Leadership (High Council of Youth - CSJ). Master's degree holder in Materials Chemistry & Organization Management. Combines technical operational rigor, chemical process safety, public sector governance, and organizational management.",
  summaryAr: "شخصية متعددة المهارات يمتلك أكثر من ست سنوات من الخبرة الميدانية في قطاعات البتروكيماويات (مجمع سوناطراك لإنتاج الميثانول)، الصحة العمومية (تشغيل أجهزة التصوير الطبي والتشخيص)، والعمل المؤسساتي والعمومي (المجلس الأعلى للشباب). حاصل على شهادتي ماستر في كيمياء المواد وتسيير المنظمات، يجمع بين الكفاءة التقنية، إدارة المنشآت، والتخطيط الاستراتيجي.",
  politicalRoleEn: "Member of the High Council of Youth Algeria (CSJ) - Commission of Education, Vocational Training & Higher Education",
  politicalRoleAr: "عضو المجلس الأعلى للشباب - لجنة التربية، التكوين المهني، والتعليم العالي والبحث العلمي",
  experiences: [
    {
      id: "exp-1",
      companyEn: "Sonatrach (Methanol Petrochemical Complex - CP1Z)",
      companyAr: "سوناطراك (مجمع البتروكيماويات لإنتاج الميثانول - CP1Z)",
      roleEn: "Plant Operations & Process Technician",
      roleAr: "إطار وتقني تشغيل المنشآت البتروكيماوية",
      startDate: "Sep 2023",
      endDate: "Present",
      locationEn: "Arzew, Oran, Algeria",
      locationAr: "أرزيو، وهران، الجزائر",
      bulletsEn: [
        "Operate and continuously monitor industrial chemical reaction loops, synthesis units, and distillation columns for methanol production at CP1Z complex.",
        "Execute daily operational parameters checks, pressure/temperature control, and process stability adjustments ensuring maximum yield and zero safety violations.",
        "Implement hazardous chemical handling safety protocols (HSE) and coordinate routine preventive maintenance shutdowns with engineering teams.",
        "Perform chemical process quality analysis and technical troubleshooting on production lines to minimize downtime."
      ],
      bulletsAr: [
        "الإشراف والتشغيل التقني اليومي لوحدات التفاعل والتصنيع وأبراج التقطير لإنتاج الميثانول بمجمع سوناطراك (CP1Z).",
        "مراقبة الضغط والحرارة والتدفق وتعديل المؤشرات التشغيلية لضمان استقرار العمليات الإنتاجية وأقصى درجات الأمان.",
        "تطبيق بروتوكولات السلامة الصناعية والبيئية (HSE) والتنسيق مع فرق الهندسة والصيانة في عمليات التوقف الوقائي.",
        "تحليل جودة العينات والمساهمة في معالجة الأعطال التقنية على خطوط الإنتاج لتقليل التوقف غير المخطط له."
      ]
    },
    {
      id: "exp-2",
      companyEn: "High Council of Youth - Algeria (CSJ)",
      companyAr: "المجلس الأعلى للشباب - الجزائر",
      roleEn: "Council Member - Education & Higher Education Commission",
      roleAr: "عضو المجلس الأعلى للشباب - لجنة التربية والتكوين والتعليم العالي",
      startDate: "Aug 2022",
      endDate: "2026",
      locationEn: "Algiers / Oran, Algeria",
      locationAr: "الجزائر العاصمة / وهران",
      bulletsEn: [
        "Formulate public policy recommendations for higher education reform, vocational training integration, and youth empowerment.",
        "Lead national delegations and organize national youth forums, digital transformation symposiums, and administrative strategy workshops.",
        "Represent youth perspectives in inter-ministerial advisory committees and streamline coordination between government bodies and local communities."
      ],
      bulletsAr: [
        "المساهمة في تقديم مقترحات السياسات العمومية وتطوير منظومة التعليم العالي والبحث العلمي والتكوين المهني.",
        "تنظيم وإدارة ملتقيات وطنية ومؤتمرات في مجالات التحول الرقمي، الابتكار الشبابي، والسياسات العامة.",
        "التنسيق المباشر مع اللجان الوزارية والمؤسسات الحكومية لتفعيل برامج تطوير مهارات الشباب والقيادة."
      ]
    },
    {
      id: "exp-3",
      companyEn: "EPSP Es Senia (Public Health Care Facility)",
      companyAr: "المؤسسة العمومية للصحة الجوارية - السانية",
      roleEn: "Medical Imaging Technologist (Public Health)",
      roleAr: "مسؤول تشغيل أجهزة التصوير الطبي (الراديو والتصوير الشعاعي)",
      startDate: "Sep 2021",
      endDate: "Sep 2024",
      locationEn: "Es Senia, Oran, Algeria",
      locationAr: "السانية، وهران، الجزائر",
      bulletsEn: [
        "Operated digital radiography (X-Ray) diagnostic systems, ensuring compliant radiological safety and precise diagnostic imaging.",
        "Managed daily patient diagnostic workflows, radiological records documentation, and strict radiation protection standards.",
        "Maintained medical device calibration schedules and collaborated with multi-disciplinary clinical teams for optimal patient diagnostic outcomes."
      ],
      bulletsAr: [
        "إدارة وتشغيل أجهزة التصوير الشعاعي التشخيصي (Rx Standard) وتطبيق معايير الوقاية الإشعاعية.",
        "تنسيق سير عمل المرضى، توثيق السجلات الطبية التشخيصية، والالتزام بالسلامة البيولوجية والإشعاعية.",
        "متابعة المعايرة الدورية للأجهزة الطبية والتواصل المستمر مع الأطباء المعالجين لضمان دقة النتائج."
      ]
    },
    {
      id: "exp-4",
      companyEn: "EHS Canastel Oran (Pediatric Specialized Hospital)",
      companyAr: "المؤسسة الاستشفائية المتخصصة في طب الأطفال - كاناستال",
      roleEn: "Specialized Medical Imaging Technologist (MRI / CT / X-Ray)",
      roleAr: "إطار بالصحة العمومية - تشغيل أجهزة IRM و TDM و Rx",
      startDate: "Aug 2019",
      endDate: "Sep 2021",
      locationEn: "Canastel, Oran, Algeria",
      locationAr: "كاناستال، وهران، الجزائر",
      bulletsEn: [
        "Executed high-precision pediatric Magnetic Resonance Imaging (MRI / IRM), Computed Tomography (CT Scan / TDM), and standard X-Rays.",
        "Adhered to specialized pediatric radiation dosage minimization techniques and emergency trauma scanning protocols.",
        "Optimized image acquisition contrast parameters and maintained sterile diagnostic operating environments."
      ],
      bulletsAr: [
        "تشغيل أجهزة الرنين المغناطيسي (IRM) والمسح القطعي (TDM) والأشعة السينية الخاصة بطب الأطفال بدقة عالية.",
        "تطبيق تقنيات خفض الجرعات الإشعاعية للأطفال والتعامل مع حالات الطوارئ والحوادث الحرجة.",
        "معالجة وتحسين جودة الصور التشخيصية وتأمين بيئة العمل المعقمة والآمنة."
      ]
    }
  ],
  education: [
    {
      id: "edu-1",
      institutionEn: "Université de Formation Continue (UFC Oran)",
      institutionAr: "جامعة التكوين المتواصل - وهران",
      degreeEn: "Master 2 in Organization Management (Management des Organisations)",
      degreeAr: "ماستر 2 في تسيير المنظمات",
      startDate: "2023",
      endDate: "2025",
      detailsEn: "Specialized in strategic management, organizational leadership, public administration, and human resources optimization.",
      detailsAr: "تخصص في التسيير الاستراتيجي، قيادة المنظمات، الإدارة العامة، وتطوير الأداء المؤسساتي."
    },
    {
      id: "edu-2",
      institutionEn: "Université d'Oran 01 Ahmed Ben Bella",
      institutionAr: "جامعة وهران 01 أحمد بن بلة",
      degreeEn: "Master 2 in Materials Chemistry (Chimie des Matériaux)",
      degreeAr: "ماستر 2 في كيمياء المواد",
      startDate: "2021",
      endDate: "2023",
      detailsEn: "Advanced study of chemical synthesis, materials characterization, polymer dynamics, and industrial chemical process design.",
      detailsAr: "دراسات متقدمة في التركيب الكيميائي، خصائص المواد، الكيمياء الصناعية، وهندسة التفاعلات."
    },
    {
      id: "edu-3",
      institutionEn: "Université d'Oran 01 Ahmed Ben Bella",
      institutionAr: "جامعة وهران 01 أحمد بن بلة",
      degreeEn: "Bachelor / Licence in Process Engineering (Génie des Procédés - Chimie)",
      degreeAr: "ليسانس في هندسة الطرائق (كيمياء)",
      startDate: "2015",
      endDate: "2021",
      detailsEn: "Core foundation in thermodynamics, fluid mechanics, chemical reaction engineering, and plant unit operations.",
      detailsAr: "دراسة الديناميكا الحرارية، ميكانيكا الموائع، الهندسة الكيميائية، وتشغيل الوحدات الصناعية."
    },
    {
      id: "edu-4",
      institutionEn: "National Institute of Paramedical Training (INFSPM Oran)",
      institutionAr: "المعهد الوطني لتكوين شبه الطبيين - وهران",
      degreeEn: "State Diploma in Medical Imaging Technology (Bac+3)",
      degreeAr: "شهادة تخصص في التصوير الطبي (بكالوريا +3)",
      startDate: "2016",
      endDate: "2019",
      detailsEn: "Clinical & technical certification in radiodiagnostics, medical physics, radiological safety, and MRI/CT operations.",
      detailsAr: "تكوين متخصص في الفيزياء الطبية، الوقاية الإشعاعية، وتقنيات التشغيل في الأشعة والرنين والمسح المقطعي."
    }
  ],
  certifications: [
    {
      id: "cert-1",
      titleEn: "Project Management Certificate",
      titleAr: "شهادة في إدارة المشاريع (Project Management)",
      issuerEn: "Professional Training Institute",
      issuerAr: "مركز التكوين المهني المستمر",
      year: "2023"
    },
    {
      id: "cert-2",
      titleEn: "Administrative Communication Techniques",
      titleAr: "تقنيات الاتصال الإداري والتنظيمي",
      issuerEn: "National Training Institute for Local Authorities (INFC Bechar)",
      issuerAr: "المعهد الوطني لتكوين إطارات الجماعات المحلية - بشار",
      year: "2022"
    },
    {
      id: "cert-3",
      titleEn: "Public Policy & State Governance Training",
      titleAr: "تكوين في السياسات العمومية واستراتيجيات الدولة",
      issuerEn: "National School of Administration (ENA)",
      issuerAr: "المدرسة العليا للإدارة - الجزائر",
      year: "2023"
    },
    {
      id: "cert-4",
      titleEn: "Digital Marketing & Strategy Certification",
      titleAr: "دورة متخصصة في التسويق والاستراتيجيا الرقمية",
      issuerEn: "Digital Innovation Center",
      issuerAr: "مركز الإبداع الرقمي والتسويق",
      year: "2022"
    }
  ],
  skillCategories: [
    {
      id: "cat-1",
      categoryEn: "Petrochemicals & Process Operations",
      categoryAr: "الهندسة البتروكيماوية وتشغيل المنشآت",
      skillsEn: [
        "Methanol Production (CP1Z)",
        "Chemical Reaction Engineering",
        "Distillation & Synthesis Units",
        "HSE & Industrial Safety Protocols",
        "Process Parameter Control",
        "Preventive Maintenance & Calibration"
      ],
      skillsAr: [
        "إنتاج الميثانول (مجمع CP1Z)",
        "هندسة التفاعلات الكيميائية",
        "تشغيل وحدات التقطير والتركيب",
        "معايير السلامة الصناعية (HSE)",
        "التحكم في المؤشرات التشغيلية",
        "الصيانة الوقائية والمعايرة"
      ]
    },
    {
      id: "cat-2",
      categoryEn: "Healthcare & Diagnostic Medical Imaging",
      categoryAr: "التصوير الطبي والأنظمة الصحية",
      skillsEn: [
        "Standard Digital Radiography (Rx)",
        "Magnetic Resonance Imaging (MRI / IRM)",
        "Computed Tomography (CT Scan / TDM)",
        "Pediatric Diagnostic Protocols",
        "Radiation Protection & Safety",
        "Medical Equipment Operations"
      ],
      skillsAr: [
        "التصوير الشعاعي الرقمي (Rx)",
        "التصوير بالرنين المغناطيسي (IRM)",
        "التصوير القطعي المبرمج (TDM)",
        "بروتوكولات طب الأطفال",
        "الوقاية الإشعاعية والسلامة البيولوجية",
        "تشغيل وإدارة المعدات الطبية"
      ]
    },
    {
      id: "cat-3",
      categoryEn: "Management, Governance & Leadership",
      categoryAr: "الإدارة، التسيير والعمل المؤسساتي",
      skillsEn: [
        "Organizational Management",
        "Public Policy Formulation",
        "Project Management",
        "Inter-Agency Coordination",
        "Team Leadership",
        "Strategic Planning"
      ],
      skillsAr: [
        "تسيير وإدارة المنظمات",
        "صياغة السياسات العمومية",
        "إدارة المشاريع والتخطيط",
        "التنسيق بين القطاعات والمؤسسات",
        "قيادة فرق العمل والتنسيق",
        "التخطيط الاستراتيجي"
      ]
    },
    {
      id: "cat-4",
      categoryEn: "Digital Tools & Software",
      categoryAr: "البرمجيات والحلول الرقمية",
      skillsEn: [
        "Microsoft Office Suite (Word, Excel, PowerPoint)",
        "Data Analysis & Reporting",
        "Graphic Design Software",
        "Digital Tourism Solutions",
        "Digital Communication Tools"
      ],
      skillsAr: [
        "البرامج المكتبية (Excel, Word, PowerPoint)",
        "تحليل البيانات وإعداد التقارير",
        "برامج التصميم والتصميم الجرافيكي",
        "حلول السياحة والإدارة الرقمية",
        "أدوات التواصل الرقمي"
      ]
    }
  ],
  languages: [
    {
      languageEn: "Arabic",
      languageAr: "اللغة العربية",
      levelEn: "Native / Mother Tongue",
      levelAr: "اللغة الأم"
    },
    {
      languageEn: "French",
      languageAr: "اللغة الفرنسية",
      levelEn: "Full Professional Proficiency",
      levelAr: "مستوى مهني متقدم"
    },
    {
      languageEn: "English",
      languageAr: "اللغة الإنجليزية",
      levelEn: "Professional & Technical Proficiency",
      levelAr: "مستوى مهني وتقني"
    }
  ]
};

// Default initial profile set to blankProfile as requested
export const initialProfile: CandidateProfile = blankProfile;

