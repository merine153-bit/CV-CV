import React from 'react';
import { Language } from '../types';
import { Globe, Printer, Download, RotateCcw } from 'lucide-react';
import { CvLogo } from './CvLogo';

interface NavbarProps {
  lang: Language;
  onToggleLang: (newLang: Language) => void;
  showPhoto: boolean;
  onTogglePhoto: (show: boolean) => void;
  onResetData: () => void;
  onPrint: () => void;
  onDownloadPdf: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  showPhoto,
  onTogglePhoto,
  onResetData,
  onPrint,
  onDownloadPdf,
}) => {
  const isAr = lang === 'ar';

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md bg-opacity-90 print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <CvLogo size={40} />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-white text-base sm:text-lg tracking-tight">
                Cv % ATS
              </h1>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100% Score
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              {isAr
                ? 'مصمم لجميع أنظمة القراءة الآلية (Sonatrach, Workday, Taleo)'
                : 'Optimized for global ATS software & corporate recruiters'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Language Switcher */}
          <button
            onClick={() => onToggleLang(isAr ? 'en' : 'ar')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
            title={isAr ? 'Switch to English (LTR)' : 'التحويل للغة العربية (RTL)'}
          >
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span>{isAr ? 'English' : 'العربية'}</span>
          </button>

          {/* Reset Button */}
          <button
            onClick={onResetData}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-slate-200 text-xs transition-all hidden md:flex items-center gap-1"
            title={isAr ? 'إعادة استعادة البيانات الأصلية' : 'Reset to original candidate data'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Direct Print Button */}
          <button
            onClick={onPrint}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition-all"
            title={isAr ? 'طباعة مباشرة عبر المتصفح' : 'Direct Print'}
          >
            <Printer className="w-3.5 h-3.5 text-slate-300" />
            <span className="hidden sm:inline">{isAr ? 'طباعة' : 'Print'}</span>
          </button>

          {/* Download PDF Button */}
          <button
            onClick={onDownloadPdf}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition-all"
            title={isAr ? 'تنزيل ملف PDF' : 'Download PDF file'}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isAr ? 'تحميل PDF' : 'Download PDF'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
