import React from 'react';
import { CandidateProfile, Language } from '../../types';

interface TemplateProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
}

export const CompactTemplate: React.FC<TemplateProps> = ({ profile, lang, showPhoto }) => {
  const isAr = lang === 'ar';

  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  return (
    <div className="space-y-5 text-xs">
      {/* Tech Compact Header */}
      <div 
        className="p-5 rounded-lg border-s-4 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
        style={{ backgroundColor: '#f0f9ff', borderColor: '#0284c7' }}
      >
        <div className="flex items-center gap-4">
          {showPhoto && profile.photoUrl && (
            <img 
              src={profile.photoUrl} 
              alt={isAr ? profile.fullNameAr : profile.fullNameEn}
              className="w-16 h-16 rounded-md border-2 border-[#0284c7] object-cover shrink-0 shadow-sm"
            />
          )}
          <div className="space-y-2.5">
            <h1 className="text-2xl md:text-3xl font-black tracking-tight leading-snug" style={{ color: '#0369a1' }}>
              {isAr ? profile.fullNameAr : profile.fullNameEn}
            </h1>
            <p className="text-xs font-bold uppercase tracking-wider leading-normal pt-1" style={{ color: '#0e7490' }}>
              {isAr ? profile.titleAr : profile.titleEn}
            </p>
          </div>
        </div>

        {hasContactInfo && (
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-semibold" style={{ color: '#0369a1' }}>
            {profile.email && <span className="cv-badge inline-block bg-white/80 px-2 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#bae6fd', color: '#0369a1' }}>{profile.email}</span>}
            {profile.phone && <span className="cv-badge inline-block bg-white/80 px-2 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#bae6fd', color: '#0369a1' }} dir="ltr">{profile.phone}</span>}
            {(isAr ? profile.addressAr : profile.addressEn) && <span className="cv-badge inline-block bg-white/80 px-2 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#bae6fd', color: '#0369a1' }}>{isAr ? profile.addressAr : profile.addressEn}</span>}
          </div>
        )}
      </div>

      {/* 1. Technical Summary */}
      {hasSummary && (
        <section className="cv-section space-y-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
            {isAr ? 'الملخص التقني والمهني' : 'TECHNICAL & PROFESSIONAL SUMMARY'}
          </div>
          {summaryText && (
            <p className="cv-item text-[12px] leading-relaxed text-justify px-1" style={{ color: '#1e293b' }}>
              {summaryText}
            </p>
          )}

          {politicalRoleText && (
            <div 
              className="cv-item mt-2 text-[11px] font-medium p-2.5 rounded border-s-4"
              style={{ backgroundColor: '#f0f9ff', color: '#0369a1', borderColor: '#0284c7' }}
            >
              <strong>{isAr ? 'الدور المؤسساتي:' : 'Institutional Role:'}</strong>{' '}
              {politicalRoleText}
            </div>
          )}
        </section>
      )}

      {/* 2. Technical Skills First (Tech focus!) */}
      {validSkillCategories.length > 0 && (
        <section className="cv-section space-y-2">
          <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
            {isAr ? 'المهارات التقنية والتكنولوجيا' : 'TECHNICAL SKILLS & STACK'}
          </div>

          <div className="space-y-2 px-1 text-[11px]">
            {validSkillCategories.map((cat) => {
              const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
              const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
              return (
                <div key={cat.id} className="cv-item flex flex-col sm:flex-row sm:items-center gap-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  {categoryName && (
                    <span className="font-bold shrink-0 min-w-[140px]" style={{ color: '#0369a1' }}>
                      {categoryName}:
                    </span>
                  )}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    {skills.map((sk, sIdx) => (
                      <span 
                        key={sIdx} 
                        className="cv-badge inline-block text-center text-[10px] px-2.5 py-1 rounded border font-semibold leading-snug align-middle"
                        style={{ backgroundColor: '#f0f9ff', color: '#0369a1', borderColor: '#bae6fd' }}
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 3. Work Experience */}
      {validExperiences.length > 0 && (
        <section className="cv-section space-y-2">
          <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
            {isAr ? 'الخبرة العملية والمشاريع' : 'PROFESSIONAL EXPERIENCE & PROJECTS'}
          </div>

          <div className="space-y-3 px-1">
            {validExperiences.map((exp) => {
              const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
              const role = isAr ? exp.roleAr : exp.roleEn;
              const company = isAr ? exp.companyAr : exp.companyEn;
              const location = isAr ? exp.locationAr : exp.locationEn;
              return (
                <div key={exp.id} className="cv-item space-y-1" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex flex-wrap justify-between items-baseline gap-1">
                    <span className="text-[11px] font-black uppercase" style={{ color: '#0f172a' }}>
                      {role && company ? (
                        <>
                          {role} <span className="mx-1" style={{ color: '#0284c7' }}>-</span> {company}
                        </>
                      ) : (
                        role || company
                      )}
                    </span>
                    {(exp.startDate || exp.endDate) && (
                      <span 
                        className="text-[10px] font-bold px-2 py-0.5 rounded border whitespace-nowrap"
                        style={{ backgroundColor: '#f0f9ff', color: '#0369a1', borderColor: '#bae6fd' }}
                      >
                        {exp.startDate} {exp.startDate && exp.endDate ? '—' : ''} {exp.endDate}
                      </span>
                    )}
                  </div>

                  {location && (
                    <div className="text-[10px] font-medium text-slate-500 italic">
                      {location}
                    </div>
                  )}

                  {bullets.length > 0 && (
                    <ul className="space-y-1 text-[11px] pt-0.5" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
                      {bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 leading-normal">
                          <span className="shrink-0 select-none text-[10px] font-bold mt-0.5" style={{ color: '#0284c7' }}>▶</span>
                          <span className="flex-1">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Education & Certifications in 2 Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {validEducation.length > 0 && (
          <section className="cv-section space-y-2">
            <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
              {isAr ? 'التعليم والشهادات' : 'EDUCATION'}
            </div>

            <div className="space-y-2 px-1">
              {validEducation.map((edu) => {
                const degree = isAr ? edu.degreeAr : edu.degreeEn;
                const institution = isAr ? edu.institutionAr : edu.institutionEn;
                return (
                  <div key={edu.id} className="cv-item space-y-0.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                    <div className="flex flex-wrap justify-between items-baseline gap-1">
                      <h3 className="font-bold text-[11px] uppercase" style={{ color: '#0f172a' }}>
                        {degree}
                      </h3>
                      {(edu.startDate || edu.endDate) && (
                        <span 
                          className="text-[10px] font-bold px-1.5 py-0.5 rounded border whitespace-nowrap"
                          style={{ backgroundColor: '#f0f9ff', color: '#0369a1', borderColor: '#bae6fd' }}
                        >
                          {edu.startDate} {edu.startDate && edu.endDate ? '—' : ''} {edu.endDate}
                        </span>
                      )}
                    </div>
                    {institution && (
                      <div className="text-[10px] italic font-medium text-slate-600">
                        {institution}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {validCertifications.length > 0 && (
          <section className="cv-section space-y-2">
            <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
              {isAr ? 'التدريب والشهادات' : 'CERTIFICATIONS'}
            </div>

            <ul className="space-y-1 text-[11px] px-1" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
              {validCertifications.map((cert) => {
                const title = isAr ? cert.titleAr : cert.titleEn;
                const issuer = isAr ? cert.issuerAr : cert.issuerEn;
                return (
                  <li key={cert.id} className="cv-item flex items-start gap-1.5 leading-snug">
                    <span className="shrink-0 text-[10px] font-bold" style={{ color: '#0369a1' }}>✔</span>
                    <span className="flex-1">
                      <strong style={{ color: '#0f172a' }}>{title}</strong>
                      {issuer && <span className="text-[10px] block text-slate-500">{issuer} {cert.year ? `(${cert.year})` : ''}</span>}
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>
        )}
      </div>

      {/* 5. Languages */}
      {validLanguages.length > 0 && (
        <section className="cv-section space-y-1.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <div className="px-3 py-1 rounded border-s-4 font-black uppercase tracking-wider text-xs" style={{ backgroundColor: '#e0f2fe', borderColor: '#0284c7', color: '#0369a1' }}>
            {isAr ? 'اللغات' : 'LANGUAGES'}
          </div>
          <div className="cv-item flex flex-wrap gap-2 text-[11px] px-1 font-medium">
            {validLanguages.map((langItem, idx) => {
              const name = isAr ? langItem.languageAr : langItem.languageEn;
              const level = isAr ? langItem.levelAr : langItem.levelEn;
              return (
                <div 
                  key={idx} 
                  className="px-2.5 py-1 rounded border font-semibold text-[10px]"
                  style={{ backgroundColor: '#f0f9ff', color: '#0369a1', borderColor: '#bae6fd' }}
                >
                  <strong style={{ color: '#0284c7' }}>{name}:</strong>{' '}
                  <span style={{ color: '#0f172a' }}>{level}</span>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};
