import React from 'react';
import { CandidateProfile, Language } from '../../types';

interface TemplateProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
}

export const CorporateTemplate: React.FC<TemplateProps> = ({ profile, lang, showPhoto }) => {
  const isAr = lang === 'ar';

  const name = isAr ? profile.fullNameAr : profile.fullNameEn;
  const initials = name ? name.split(' ').map(n => n[0]).filter(Boolean).slice(0, 2).join('') : 'CV';

  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  return (
    <div className="space-y-6">
      {/* Centered Monogram & Header */}
      <div className="text-center space-y-3 pb-6 border-b-4 border-double" style={{ borderColor: '#881337' }}>
        {showPhoto && profile.photoUrl ? (
          <div className="flex justify-center">
            <img 
              src={profile.photoUrl} 
              alt={name}
              className="w-20 h-20 rounded-full border-2 border-[#881337] object-cover shadow-md"
            />
          </div>
        ) : (
          <div className="mx-auto w-12 h-12 rounded-full border-2 flex items-center justify-center font-black text-sm tracking-wider shadow-sm" style={{ backgroundColor: '#fff1f2', borderColor: '#881337', color: '#881337' }}>
            {initials}
          </div>
        )}

        <div className="space-y-2.5">
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight uppercase leading-snug" style={{ color: '#4c0519' }}>
            {name}
          </h1>
          <p className="text-xs font-bold uppercase tracking-widest leading-normal pt-1" style={{ color: '#be123c' }}>
            {isAr ? profile.titleAr : profile.titleEn}
          </p>
        </div>

        {hasContactInfo && (
          <div className="flex flex-wrap justify-center items-center gap-x-4 gap-y-1 text-[11px] font-medium pt-1" style={{ color: '#475569' }}>
            {profile.email && <span>{profile.email}</span>}
            {profile.email && profile.phone && <span style={{ color: '#fda4af' }}>•</span>}
            {profile.phone && <span dir="ltr">{profile.phone}</span>}
            {profile.phone && (isAr ? profile.addressAr : profile.addressEn) && <span style={{ color: '#fda4af' }}>•</span>}
            {(isAr ? profile.addressAr : profile.addressEn) && <span>{isAr ? profile.addressAr : profile.addressEn}</span>}
          </div>
        )}
      </div>

      {/* 1. Summary */}
      {hasSummary && (
        <section className="cv-section mb-6" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <div className="text-center mb-3">
            <h2 className="text-xs font-black uppercase tracking-widest inline-block px-4 py-1 border-y border-double" style={{ color: '#881337', borderColor: '#fecdd3' }}>
              — {isAr ? 'الملخص المهني' : 'EXECUTIVE SUMMARY'} —
            </h2>
          </div>
          {summaryText && (
            <p className="cv-item text-[12px] leading-relaxed text-justify px-3" style={{ color: '#27272a' }}>
              {summaryText}
            </p>
          )}

          {politicalRoleText && (
            <div 
              className="cv-item mt-3 text-[11px] font-medium p-3 rounded text-center border"
              style={{ backgroundColor: '#fff1f2', color: '#881337', borderColor: '#fecdd3' }}
            >
              <strong>{isAr ? 'الدور المؤسساتي:' : 'Institutional Role:'}</strong>{' '}
              {politicalRoleText}
            </div>
          )}
        </section>
      )}

      {/* 2. Work Experience */}
      {validExperiences.length > 0 && (
        <section className="cv-section mb-6">
          <div className="text-center mb-4">
            <h2 className="text-xs font-black uppercase tracking-widest inline-block px-4 py-1 border-y border-double" style={{ color: '#881337', borderColor: '#fecdd3' }}>
              — {isAr ? 'السجل المهني والخبرات' : 'PROFESSIONAL EXPERIENCE'} —
            </h2>
          </div>

          <div className="space-y-4 px-2">
            {validExperiences.map((exp) => {
              const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
              const role = isAr ? exp.roleAr : exp.roleEn;
              const company = isAr ? exp.companyAr : exp.companyEn;
              const location = isAr ? exp.locationAr : exp.locationEn;
              return (
                <div key={exp.id} className="cv-item space-y-1.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex flex-wrap justify-between items-baseline border-b pb-1" style={{ borderColor: '#f3f4f6' }}>
                    <div className="text-[12px] font-bold uppercase" style={{ color: '#4c0519' }}>
                      {role} <span style={{ color: '#9f1239' }}>|</span> {company}
                    </div>
                    {(exp.startDate || exp.endDate) && (
                      <span 
                        className="cv-badge inline-block text-[10px] font-bold px-2 py-0.5 rounded border whitespace-nowrap leading-snug align-middle"
                        style={{ backgroundColor: '#fff1f2', color: '#881337', borderColor: '#fecdd3' }}
                      >
                        {exp.startDate} {exp.startDate && exp.endDate ? '—' : ''} {exp.endDate}
                      </span>
                    )}
                  </div>

                  {location && (
                    <div className="text-[10px] font-semibold italic text-slate-500">
                      {location}
                    </div>
                  )}

                  {bullets.length > 0 && (
                    <ul className="space-y-1 text-[11px] pt-1" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#3f3f46' }}>
                      {bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 leading-normal">
                          <span className="shrink-0 select-none text-[10px] font-bold mt-1" style={{ color: '#be123c' }}>❖</span>
                          <span className="flex-1">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 3. Education */}
      {validEducation.length > 0 && (
        <section className="cv-section mb-6">
          <div className="text-center mb-3">
            <h2 className="text-xs font-black uppercase tracking-widest inline-block px-4 py-1 border-y border-double" style={{ color: '#881337', borderColor: '#fecdd3' }}>
              — {isAr ? 'المؤهلات العلمية' : 'ACADEMIC QUALIFICATIONS'} —
            </h2>
          </div>

          <div className="space-y-3 px-2">
            {validEducation.map((edu) => {
              const degree = isAr ? edu.degreeAr : edu.degreeEn;
              const institution = isAr ? edu.institutionAr : edu.institutionEn;
              const details = isAr ? edu.detailsAr : edu.detailsEn;
              return (
                <div key={edu.id} className="cv-item space-y-0.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-[11px] uppercase" style={{ color: '#4c0519' }}>
                      {degree}
                    </h3>
                    {(edu.startDate || edu.endDate) && (
                      <span 
                        className="cv-badge inline-block text-[10px] font-bold px-2 py-0.5 rounded border whitespace-nowrap leading-snug align-middle"
                        style={{ backgroundColor: '#fff1f2', color: '#881337', borderColor: '#fecdd3' }}
                      >
                        {edu.startDate} {edu.startDate && edu.endDate ? '—' : ''} {edu.endDate}
                      </span>
                    )}
                  </div>
                  {institution && (
                    <div className="text-[11px] italic font-medium text-slate-600">
                      {institution}
                    </div>
                  )}
                  {details && (
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {details}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Technical Skills & Competencies */}
      {validSkillCategories.length > 0 && (
        <section className="cv-section mb-6">
          <div className="text-center mb-3">
            <h2 className="text-xs font-black uppercase tracking-widest inline-block px-4 py-1 border-y border-double" style={{ color: '#881337', borderColor: '#fecdd3' }}>
              — {isAr ? 'المهارات التقنية' : 'TECHNICAL COMPETENCIES'} —
            </h2>
          </div>

          <div className="space-y-2.5 px-2 text-[11px]">
            {validSkillCategories.map((cat) => {
              const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
              const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
              return (
                <div key={cat.id} className="cv-item flex flex-col sm:flex-row sm:items-center gap-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  {categoryName && (
                    <span className="font-bold shrink-0 min-w-[140px]" style={{ color: '#881337' }}>
                      {categoryName}:
                    </span>
                  )}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    {skills.map((sk, sIdx) => (
                      <span 
                        key={sIdx} 
                        className="cv-badge inline-block text-center text-[10px] px-2.5 py-1 rounded border font-semibold leading-snug align-middle"
                        style={{ backgroundColor: '#fff1f2', color: '#881337', borderColor: '#fecdd3' }}
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 5. Certifications & Languages */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {validCertifications.length > 0 && (
          <section className="cv-section" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
            <h2 className="text-xs font-black uppercase tracking-wider text-rose-900 border-b pb-1 mb-2" style={{ borderColor: '#fecdd3' }}>
              {isAr ? 'الشهادات المعتمدة' : 'CERTIFICATIONS'}
            </h2>
            <ul className="space-y-1.5 text-[11px]" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
              {validCertifications.map((cert) => {
                const title = isAr ? cert.titleAr : cert.titleEn;
                const issuer = isAr ? cert.issuerAr : cert.issuerEn;
                return (
                  <li key={cert.id} className="cv-item flex items-start gap-1.5 leading-normal">
                    <span className="shrink-0 text-[10px] font-bold text-rose-800">•</span>
                    <span className="flex-1">
                      {title && <strong style={{ color: '#4c0519' }}>{title}</strong>}
                      {issuer && <span className="text-[10px] block text-slate-500">{issuer} {cert.year ? `(${cert.year})` : ''}</span>}
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>
        )}

        {validLanguages.length > 0 && (
          <section className="cv-section" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
            <h2 className="text-xs font-black uppercase tracking-wider text-rose-900 border-b pb-1 mb-2" style={{ borderColor: '#fecdd3' }}>
              {isAr ? 'اللغات' : 'LANGUAGES'}
            </h2>
            <div className="cv-item flex flex-wrap gap-2 text-[11px] font-medium">
              {validLanguages.map((langItem, idx) => {
                const name = isAr ? langItem.languageAr : langItem.languageEn;
                const level = isAr ? langItem.levelAr : langItem.levelEn;
                return (
                  <div key={idx} className="cv-badge inline-block px-2.5 py-1 rounded border leading-snug align-middle" style={{ backgroundColor: '#fff1f2', borderColor: '#fecdd3' }}>
                    <strong style={{ color: '#881337' }}>{name}:</strong>{' '}
                    <span style={{ color: '#475569' }}>{level}</span>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
