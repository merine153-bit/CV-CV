import React from 'react';
import { CandidateProfile, Language } from '../../types';

interface TemplateProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
}

export const SidebarTemplate: React.FC<TemplateProps> = ({ profile, lang, showPhoto }) => {
  const isAr = lang === 'ar';

  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  return (
    <div className="space-y-6">
      {/* 1. Top Header Banner: Personal & Contact Information */}
      <div 
        className="p-5 rounded-xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm"
        style={{ backgroundColor: '#f0fdf4', borderColor: '#99f6e4' }}
      >
        <div className="flex items-center gap-4">
          {showPhoto && profile.photoUrl && (
            <img 
              src={profile.photoUrl} 
              alt={isAr ? profile.fullNameAr : profile.fullNameEn}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-[#0d9488] object-cover shrink-0 shadow-md"
            />
          )}
          <div className="space-y-2.5">
            <h1 className="text-2xl md:text-3xl font-black tracking-tight leading-snug" style={{ color: '#0f172a' }}>
              {isAr ? profile.fullNameAr : profile.fullNameEn}
            </h1>
            <p className="text-xs sm:text-sm font-bold uppercase tracking-wider leading-normal pt-1" style={{ color: '#0d9488' }}>
              {isAr ? profile.titleAr : profile.titleEn}
            </p>
          </div>
        </div>

        {hasContactInfo && (
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-semibold" style={{ color: '#0f766e' }}>
            {profile.email && <span className="cv-badge inline-block bg-white/80 px-2.5 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#99f6e4', color: '#0f766e' }}>{profile.email}</span>}
            {profile.phone && <span className="cv-badge inline-block bg-white/80 px-2.5 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#99f6e4', color: '#0f766e' }} dir="ltr">{profile.phone}</span>}
            {(isAr ? profile.addressAr : profile.addressEn) && <span className="cv-badge inline-block bg-white/80 px-2.5 py-0.5 rounded border leading-snug align-middle" style={{ borderColor: '#99f6e4', color: '#0f766e' }}>{isAr ? profile.addressAr : profile.addressEn}</span>}
          </div>
        )}
      </div>

      {/* 2. Professional Summary */}
      {hasSummary && (
        <section className="cv-section space-y-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <h2 className="text-xs font-black uppercase tracking-wider text-teal-800 border-b pb-1" style={{ borderColor: '#ccfbf1' }}>
            {isAr ? 'الملخص المهني' : 'PROFESSIONAL SUMMARY'}
          </h2>
          {summaryText && (
            <p className="cv-item text-[12px] leading-relaxed text-justify px-1" style={{ color: '#334155' }}>
              {summaryText}
            </p>
          )}
          {politicalRoleText && (
            <div 
              className="cv-item mt-2 text-[11px] font-medium p-2.5 rounded border-s-4"
              style={{ backgroundColor: '#f0fdf4', color: '#115e59', borderColor: '#0d9488' }}
            >
              <strong>{isAr ? 'الدور المؤسساتي:' : 'Institutional Role:'}</strong>{' '}
              {politicalRoleText}
            </div>
          )}
        </section>
      )}

      {/* 3. Work Experience */}
      {validExperiences.length > 0 && (
        <section className="cv-section space-y-3">
          <h2 className="text-xs font-black uppercase tracking-wider text-teal-800 border-b pb-1" style={{ borderColor: '#ccfbf1' }}>
            {isAr ? 'الخبرات العملية' : 'WORK EXPERIENCE'}
          </h2>

          <div className="space-y-4 px-1">
            {validExperiences.map((exp) => {
              const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
              const role = isAr ? exp.roleAr : exp.roleEn;
              const company = isAr ? exp.companyAr : exp.companyEn;
              const location = isAr ? exp.locationAr : exp.locationEn;
              return (
                <div key={exp.id} className="cv-item space-y-1" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex flex-wrap justify-between items-baseline gap-1">
                    <span className="text-[12px] font-black uppercase" style={{ color: '#0f172a' }}>
                      {role} {company ? `- ${company}` : ''}
                    </span>
                    {(exp.startDate || exp.endDate) && (
                      <span 
                        className="text-[10px] font-bold px-2 py-0.5 rounded border whitespace-nowrap"
                        style={{ backgroundColor: '#f0fdf4', color: '#0d9488', borderColor: '#99f6e4' }}
                      >
                        {exp.startDate} {exp.startDate && exp.endDate ? '—' : ''} {exp.endDate}
                      </span>
                    )}
                  </div>

                  {location && (
                    <div className="text-[10px] font-medium text-slate-500 italic">
                      {location}
                    </div>
                  )}

                  {bullets.length > 0 && (
                    <ul className="space-y-1 text-[11px] pt-1" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
                      {bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 leading-normal">
                          <span className="shrink-0 select-none text-[12px] font-bold" style={{ color: '#0d9488' }}>•</span>
                          <span className="flex-1">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Education */}
      {validEducation.length > 0 && (
        <section className="cv-section space-y-2">
          <h2 className="text-xs font-black uppercase tracking-wider text-teal-800 border-b pb-1" style={{ borderColor: '#ccfbf1' }}>
            {isAr ? 'التعليم والمؤهلات' : 'EDUCATION'}
          </h2>

          <div className="space-y-3 px-1">
            {validEducation.map((edu) => {
              const degree = isAr ? edu.degreeAr : edu.degreeEn;
              const institution = isAr ? edu.institutionAr : edu.institutionEn;
              const details = isAr ? edu.detailsAr : edu.detailsEn;
              return (
                <div key={edu.id} className="cv-item space-y-0.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex flex-wrap justify-between items-baseline gap-1">
                    <h3 className="font-bold text-[11px] uppercase" style={{ color: '#0f172a' }}>
                      {degree}
                    </h3>
                    {(edu.startDate || edu.endDate) && (
                      <span 
                        className="text-[10px] font-bold px-2 py-0.5 rounded border whitespace-nowrap"
                        style={{ backgroundColor: '#f0fdf4', color: '#0d9488', borderColor: '#99f6e4' }}
                      >
                        {edu.startDate} {edu.startDate && edu.endDate ? '—' : ''} {edu.endDate}
                      </span>
                    )}
                  </div>
                  {institution && (
                    <div className="text-[11px] italic font-medium text-slate-600">
                      {institution}
                    </div>
                  )}
                  {details && (
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {details}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 5. Styled Green Block: Skills, Certifications & Languages at the Bottom */}
      {(validSkillCategories.length > 0 || validCertifications.length > 0 || validLanguages.length > 0) && (
        <div 
          className="cv-section p-5 rounded-xl border space-y-5 shadow-sm"
          style={{ backgroundColor: '#f0fdf4', borderColor: '#99f6e4', color: '#0f766e', pageBreakInside: 'avoid', breakInside: 'avoid' }}
        >
          {/* Skills */}
          {validSkillCategories.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-xs font-black uppercase tracking-wider pb-1 border-b" style={{ color: '#0f766e', borderColor: '#5eead4' }}>
                {isAr ? 'المهارات والكفاءات' : 'SKILLS & COMPETENCIES'}
              </h3>
              <div className="space-y-2">
                {validSkillCategories.map((cat) => {
                  const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
                  const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
                  return (
                    <div key={cat.id} className="flex flex-col sm:flex-row sm:items-center gap-2">
                      {categoryName && (
                        <div className="text-[11px] font-bold uppercase shrink-0 min-w-[140px]" style={{ color: '#115e59' }}>
                          {categoryName}:
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1.5 items-center">
                        {skills.map((sk, sIdx) => (
                          <span 
                            key={sIdx} 
                            className="cv-badge inline-block text-center text-[10px] px-2.5 py-1 rounded border font-semibold leading-snug align-middle"
                            style={{ backgroundColor: '#ffffff', color: '#0f766e', borderColor: '#99f6e4' }}
                          >
                            {sk}
                          </span>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Certifications & Languages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {validCertifications.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-xs font-black uppercase tracking-wider pb-1 border-b" style={{ color: '#0f766e', borderColor: '#5eead4' }}>
                  {isAr ? 'الشهادات والتكوين' : 'CERTIFICATIONS'}
                </h3>
                <ul className="space-y-1.5 text-[11px]" style={{ color: '#134e4a' }}>
                  {validCertifications.map((cert) => {
                    const title = isAr ? cert.titleAr : cert.titleEn;
                    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
                    return (
                      <li key={cert.id} className="leading-snug flex items-start gap-1.5">
                        <span className="text-teal-700 font-bold">•</span>
                        <span className="flex-1">
                          <strong className="text-teal-950 font-bold">{title}</strong>
                          {issuer && <span className="text-[10px] block text-teal-800">{issuer} {cert.year ? `(${cert.year})` : ''}</span>}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}

            {validLanguages.length > 0 && (
              <div className="space-y-2">
                <h3 className="text-xs font-black uppercase tracking-wider pb-1 border-b" style={{ color: '#0f766e', borderColor: '#5eead4' }}>
                  {isAr ? 'اللغات' : 'LANGUAGES'}
                </h3>
                <div className="flex flex-wrap gap-2 text-[11px] font-medium" style={{ color: '#134e4a' }}>
                  {validLanguages.map((langItem, idx) => {
                    const name = isAr ? langItem.languageAr : langItem.languageEn;
                    const level = isAr ? langItem.levelAr : langItem.levelEn;
                    return (
                      <div key={idx} className="cv-badge inline-block px-2.5 py-1 rounded bg-white border border-teal-200 leading-snug align-middle">
                        <strong className="text-teal-900">{name}:</strong>{' '}
                        <span className="text-teal-800">{level}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
