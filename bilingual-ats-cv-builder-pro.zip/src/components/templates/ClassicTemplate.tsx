import React from 'react';
import { CandidateProfile, Language } from '../../types';

interface TemplateProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
}

export const ClassicTemplate: React.FC<TemplateProps> = ({ profile, lang }) => {
  const isAr = lang === 'ar';

  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div 
        className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 p-4 rounded-lg border-b-2 gap-4"
        style={{ backgroundColor: '#f8fafc', borderColor: '#0f172a' }}
      >
        <div className="space-y-2.5 mb-1">
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight leading-snug block pb-1" style={{ color: '#0f172a' }}>
            {isAr ? profile.fullNameAr : profile.fullNameEn}
          </h1>
          <p className="text-xs font-bold block pt-1 leading-normal" style={{ color: '#334155' }}>
            {isAr ? profile.titleAr : profile.titleEn}
          </p>
        </div>

        <div className="flex flex-col items-start sm:items-end text-[11px] font-medium space-y-1" style={{ color: '#475569' }}>
          <span className="font-semibold" style={{ color: '#0f172a' }}>{profile.email}</span>
          <span dir="ltr">{profile.phone}</span>
          <span>{isAr ? profile.addressAr : profile.addressEn}</span>
        </div>
      </div>

      {/* 1. Contact Information */}
      {hasContactInfo && (
        <section className="cv-section mb-6" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'معلومات الاتصال (CONTACT INFORMATION)' : 'CONTACT INFORMATION'}
          </h2>
          <div 
            className="cv-item grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] p-2.5 rounded border font-medium"
            style={{ backgroundColor: '#f8fafc', borderColor: '#e2e8f0', pageBreakInside: 'avoid', breakInside: 'avoid' }}
          >
            <div>
              <span className="font-semibold" style={{ color: '#64748b' }}>{isAr ? 'البريد الإلكتروني:' : 'Email:'} </span>
              <span className="font-bold" style={{ color: '#0f172a' }}>{profile.email}</span>
            </div>
            <div>
              <span className="font-semibold" style={{ color: '#64748b' }}>{isAr ? 'الهاتف:' : 'Phone:'} </span>
              <span className="font-bold" style={{ color: '#0f172a' }} dir="ltr">{profile.phone}</span>
            </div>
            <div>
              <span className="font-semibold" style={{ color: '#64748b' }}>{isAr ? 'الموقع/العنوان:' : 'Location:'} </span>
              <span className="font-bold" style={{ color: '#0f172a' }}>{isAr ? profile.addressAr : profile.addressEn}</span>
            </div>
          </div>
        </section>
      )}

      {/* 2. Professional Summary */}
      {hasSummary && (
        <section className="cv-section mb-6" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'الملخص المهني (PROFESSIONAL SUMMARY)' : 'PROFESSIONAL SUMMARY'}
          </h2>
          {summaryText && (
            <p className="cv-item text-[12px] leading-relaxed text-justify" style={{ color: '#1e293b' }}>
              {summaryText}
            </p>
          )}

          {politicalRoleText && (
            <div 
              className="cv-item mt-2.5 text-[11px] font-medium p-2.5 rounded border-s-2"
              style={{ backgroundColor: '#f1f5f9', color: '#1e293b', borderColor: '#0f172a' }}
            >
              <strong>{isAr ? 'الدور المؤسساتي:' : 'Institutional Role:'}</strong>{' '}
              {politicalRoleText}
            </div>
          )}
        </section>
      )}

      {/* 3. Work Experience */}
      {validExperiences.length > 0 && (
        <section className="cv-section mb-6">
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-3"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'الخبرة العملية (WORK EXPERIENCE)' : 'WORK EXPERIENCE'}
          </h2>

          <div className="space-y-4">
            {validExperiences.map((exp) => {
              const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
              const role = isAr ? exp.roleAr : exp.roleEn;
              const company = isAr ? exp.companyAr : exp.companyEn;
              const location = isAr ? exp.locationAr : exp.locationEn;
              return (
                <div key={exp.id} className="cv-item space-y-1" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="text-[11px] font-bold uppercase" style={{ color: '#0f172a' }}>
                    {[role, company].filter(Boolean).join(' | ')}
                  </div>

                  {(exp.startDate || exp.endDate || location) && (
                    <div className="text-[11px] font-medium flex flex-wrap items-center gap-x-2" style={{ color: '#475569' }}>
                      {(exp.startDate || exp.endDate) && (
                        <span className="font-semibold">
                          {exp.startDate} {exp.startDate && exp.endDate ? '—' : ''} {exp.endDate}
                        </span>
                      )}
                      {location && (exp.startDate || exp.endDate) && <span style={{ color: '#94a3b8' }}>•</span>}
                      {location && <span className="italic">{location}</span>}
                    </div>
                  )}

                  {bullets.length > 0 && (
                    <ul className="space-y-1 text-[11px] pt-0.5" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
                      {bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 leading-normal">
                          <span className="shrink-0 select-none text-[12px] font-bold mt-0.5" style={{ color: isAr ? '#047857' : '#1d4ed8' }}>•</span>
                          <span className="flex-1">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Education */}
      {validEducation.length > 0 && (
        <section className="cv-section mb-6">
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'التعليم والمؤهلات (EDUCATION)' : 'EDUCATION'}
          </h2>

          <div className="space-y-3">
            {validEducation.map((edu) => {
              const degree = isAr ? edu.degreeAr : edu.degreeEn;
              const institution = isAr ? edu.institutionAr : edu.institutionEn;
              const details = isAr ? edu.detailsAr : edu.detailsEn;
              return (
                <div key={edu.id} className="cv-item space-y-0.5" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <h3 className="font-bold text-[11px] uppercase" style={{ color: '#0f172a', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}>
                    {degree}
                  </h3>
                  {institution && (
                    <div className="text-[11px] italic font-medium" style={{ color: '#475569' }}>
                      {institution}
                    </div>
                  )}
                  {(edu.startDate || edu.endDate) && (
                    <div className="text-[11px] font-semibold" style={{ color: '#475569' }}>
                      {edu.startDate} {edu.startDate && edu.endDate ? '—' : ''} {edu.endDate}
                    </div>
                  )}
                  {details && (
                    <p className="text-[10px] mt-0.5" style={{ color: '#64748b' }}>
                      {details}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 5. Technical Skills & Competencies */}
      {validSkillCategories.length > 0 && (
        <section className="cv-section mb-6">
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'المهارات التقنية (TECHNICAL SKILLS & COMPETENCIES)' : 'SKILLS & COMPETENCIES'}
          </h2>

          <div className="space-y-2.5 text-[11px]">
            {validSkillCategories.map((cat) => {
              const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
              const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
              return (
                <div key={cat.id} className="cv-item flex flex-col sm:flex-row sm:items-center gap-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  {categoryName && (
                    <span className="font-bold shrink-0 min-w-[140px]" style={{ color: '#0f172a' }}>
                      {categoryName}:
                    </span>
                  )}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    {skills.map((sk, sIdx) => (
                      <span 
                        key={sIdx} 
                        className="cv-badge inline-block text-center text-[10px] px-2.5 py-1 rounded border font-semibold leading-snug align-middle"
                        style={{ backgroundColor: '#f1f5f9', color: '#1e293b', borderColor: '#cbd5e1' }}
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 6. Certifications */}
      {validCertifications.length > 0 && (
        <section className="cv-section mb-6" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'الدورات والتكوينات (CERTIFICATIONS & TRAINING)' : 'CERTIFICATIONS & SPECIALIZED TRAINING'}
          </h2>

          <ul className="space-y-1.5 text-[11px]" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
            {validCertifications.map((cert) => {
              const title = isAr ? cert.titleAr : cert.titleEn;
              const issuer = isAr ? cert.issuerAr : cert.issuerEn;
              return (
                <li key={cert.id} className="cv-item flex items-start gap-2 leading-normal" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <span className="shrink-0 select-none text-[12px] font-bold mt-0.5" style={{ color: isAr ? '#047857' : '#1d4ed8' }}>•</span>
                  <span className="flex-1">
                    {title && <strong style={{ color: '#0f172a' }}>{title}</strong>}
                    {title && issuer ? ' — ' : ''}
                    {issuer && <span>{issuer}</span>}
                    {cert.year && <span style={{ color: '#64748b' }}> ({cert.year})</span>}
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
      )}

      {/* 7. Languages */}
      {validLanguages.length > 0 && (
        <section className="cv-section mb-4" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <h2 
            className="text-xs font-extrabold uppercase tracking-wider border-b pb-1 mb-2.5"
            style={{ color: isAr ? '#047857' : '#1d4ed8', borderColor: isAr ? '#a7f3d0' : '#bfdbfe', breakAfter: 'avoid', pageBreakAfter: 'avoid' }}
          >
            {isAr ? 'اللغات (LANGUAGES)' : 'LANGUAGES'}
          </h2>

          <div className="cv-item flex flex-wrap gap-x-6 gap-y-1 text-[11px] font-medium" style={{ color: '#1e293b' }}>
            {validLanguages.map((langItem, idx) => {
              const name = isAr ? langItem.languageAr : langItem.languageEn;
              const level = isAr ? langItem.levelAr : langItem.levelEn;
              return (
                <div key={idx}>
                  <strong style={{ color: '#0f172a' }}>{name}:</strong>{' '}
                  <span style={{ color: '#475569' }}>{level}</span>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};
