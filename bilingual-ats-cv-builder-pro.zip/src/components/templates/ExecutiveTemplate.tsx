import React from 'react';
import { CandidateProfile, Language } from '../../types';

interface TemplateProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
}

export const ExecutiveTemplate: React.FC<TemplateProps> = ({ profile, lang, showPhoto }) => {
  const isAr = lang === 'ar';

  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  return (
    <div className="space-y-6">
      {/* Executive Dark Header Container */}
      <div 
        className="p-6 md:p-8 rounded-xl shadow-md border-b-4 mb-6"
        style={{ backgroundColor: '#0f172a', borderColor: '#d97706', color: '#ffffff' }}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {showPhoto && profile.photoUrl && (
              <img 
                src={profile.photoUrl} 
                alt={isAr ? profile.fullNameAr : profile.fullNameEn}
                className="w-16 h-16 md:w-20 md:h-20 rounded-full border-2 border-[#d97706] object-cover shrink-0 shadow-lg"
              />
            )}
            <div className="space-y-2.5">
              <h1 className="text-2xl md:text-3xl font-black tracking-wide text-white leading-snug">
                {isAr ? profile.fullNameAr : profile.fullNameEn}
              </h1>
              <p className="text-xs md:text-sm font-bold tracking-wide uppercase leading-normal pt-1" style={{ color: '#fbbf24' }}>
                {isAr ? profile.titleAr : profile.titleEn}
              </p>
            </div>
          </div>

          {hasContactInfo && (
            <div className="flex flex-wrap md:flex-col items-start md:items-end gap-2 text-[11px] font-medium pt-2 md:pt-0 border-t md:border-t-0 border-slate-700/80 w-full md:w-auto">
              {profile.email && (
                <span 
                  className="cv-badge inline-block px-2.5 py-1 rounded-md border text-[11px] font-semibold leading-snug align-middle shadow-sm"
                  style={{ backgroundColor: '#1e293b', color: '#f8fafc', borderColor: '#475569' }}
                >
                  {profile.email}
                </span>
              )}
              {profile.phone && (
                <span 
                  className="cv-badge inline-block px-2.5 py-1 rounded-md border text-[11px] font-semibold leading-snug align-middle shadow-sm"
                  style={{ backgroundColor: '#1e293b', color: '#f8fafc', borderColor: '#475569' }}
                  dir="ltr"
                >
                  {profile.phone}
                </span>
              )}
              {(isAr ? profile.addressAr : profile.addressEn) && (
                <span 
                  className="cv-badge inline-block px-2.5 py-1 rounded-md border text-[11px] font-semibold leading-snug align-middle shadow-sm"
                  style={{ backgroundColor: '#1e293b', color: '#f8fafc', borderColor: '#475569' }}
                >
                  {isAr ? profile.addressAr : profile.addressEn}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 1. Professional Summary */}
      {hasSummary && (
        <section className="cv-section mb-6" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
          <div className="flex items-center gap-2 mb-2.5 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
            <div className="w-1.5 h-4 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
            <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
              {isAr ? 'الملخص المهني والتنفيذي' : 'EXECUTIVE SUMMARY'}
            </h2>
          </div>
          {summaryText && (
            <p className="cv-item text-[12px] leading-relaxed text-justify px-2" style={{ color: '#334155' }}>
              {summaryText}
            </p>
          )}

          {politicalRoleText && (
            <div 
              className="cv-item mt-2.5 text-[11px] font-medium p-3 rounded-lg border-s-4"
              style={{ backgroundColor: '#fffbe6', color: '#78350f', borderColor: '#d97706' }}
            >
              <strong>{isAr ? 'الدور المؤسساتي والقيادي:' : 'Institutional & Executive Role:'}</strong>{' '}
              {politicalRoleText}
            </div>
          )}
        </section>
      )}

      {/* 2. Work Experience */}
      {validExperiences.length > 0 && (
        <section className="cv-section mb-6">
          <div className="flex items-center gap-2 mb-3 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
            <div className="w-1.5 h-4 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
            <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
              {isAr ? 'الخبرة العملية والقيادية' : 'WORK & EXECUTIVE EXPERIENCE'}
            </h2>
          </div>

          <div className="space-y-4 px-1">
            {validExperiences.map((exp) => {
              const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
              const role = isAr ? exp.roleAr : exp.roleEn;
              const company = isAr ? exp.companyAr : exp.companyEn;
              const location = isAr ? exp.locationAr : exp.locationEn;
              return (
                <div key={exp.id} className="cv-item space-y-1.5 p-3 rounded-lg border" style={{ backgroundColor: '#f8fafc', borderColor: '#e2e8f0', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <div className="flex flex-wrap justify-between items-baseline gap-2">
                    <div className="text-[12px] font-black uppercase" style={{ color: '#0f172a' }}>
                      {role} <span style={{ color: '#d97706' }}>—</span> {company}
                    </div>
                    {(exp.startDate || exp.endDate) && (
                      <span className="cv-badge inline-block text-[10px] font-bold px-2 py-0.5 rounded leading-snug align-middle" style={{ backgroundColor: '#1e293b', color: '#fbbf24' }}>
                        {exp.startDate} {exp.startDate && exp.endDate ? '—' : ''} {exp.endDate}
                      </span>
                    )}
                  </div>

                  {location && (
                    <div className="text-[11px] font-semibold italic" style={{ color: '#64748b' }}>
                      {location}
                    </div>
                  )}

                  {bullets.length > 0 && (
                    <ul className="space-y-1.5 text-[11px] pt-1" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
                      {bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2 leading-normal">
                          <span className="shrink-0 select-none text-[10px] font-bold mt-1" style={{ color: '#d97706' }}>◆</span>
                          <span className="flex-1">{b}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 3. Education */}
      {validEducation.length > 0 && (
        <section className="cv-section mb-6">
          <div className="flex items-center gap-2 mb-2.5 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
            <div className="w-1.5 h-4 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
            <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
              {isAr ? 'المؤهلات والأكاديميا' : 'EDUCATION & ACADEMICS'}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 px-1">
            {validEducation.map((edu) => {
              const degree = isAr ? edu.degreeAr : edu.degreeEn;
              const institution = isAr ? edu.institutionAr : edu.institutionEn;
              const details = isAr ? edu.detailsAr : edu.detailsEn;
              return (
                <div key={edu.id} className="cv-item p-3 rounded-lg border space-y-1" style={{ backgroundColor: '#f8fafc', borderColor: '#e2e8f0', pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  <h3 className="font-bold text-[11px] uppercase" style={{ color: '#0f172a' }}>
                    {degree}
                  </h3>
                  {institution && (
                    <div className="text-[11px] font-semibold" style={{ color: '#475569' }}>
                      {institution}
                    </div>
                  )}
                  {(edu.startDate || edu.endDate) && (
                    <div className="text-[10px] font-medium" style={{ color: '#d97706' }}>
                      {edu.startDate} {edu.startDate && edu.endDate ? '—' : ''} {edu.endDate}
                    </div>
                  )}
                  {details && (
                    <p className="text-[10px]" style={{ color: '#64748b' }}>
                      {details}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. Technical Skills & Competencies */}
      {validSkillCategories.length > 0 && (
        <section className="cv-section mb-6">
          <div className="flex items-center gap-2 mb-2.5 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
            <div className="w-1.5 h-4 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
            <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
              {isAr ? 'المهارات والكفاءات الرئيسية' : 'EXECUTIVE SKILLS & CORE COMPETENCIES'}
            </h2>
          </div>

          <div className="space-y-3 px-1 text-[11px]">
            {validSkillCategories.map((cat) => {
              const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
              const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
              return (
                <div key={cat.id} className="cv-item flex flex-col sm:flex-row sm:items-center gap-2" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
                  {categoryName && (
                    <span className="font-bold shrink-0 min-w-[140px]" style={{ color: '#0f172a' }}>
                      {categoryName}:
                    </span>
                  )}
                  <div className="flex flex-wrap gap-1.5 items-center">
                    {skills.map((sk, sIdx) => (
                      <span 
                        key={sIdx} 
                        className="cv-badge inline-block text-center text-[10px] px-2.5 py-1 rounded border font-semibold leading-snug align-middle"
                        style={{ backgroundColor: '#1e293b', color: '#fef3c7', borderColor: '#d97706' }}
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* 5. Certifications & Languages side-by-side */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {validCertifications.length > 0 && (
          <section className="cv-section" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
            <div className="flex items-center gap-2 mb-2 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
              <div className="w-1.5 h-3.5 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
              <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
                {isAr ? 'الشهادات المعتمدة' : 'CERTIFICATIONS'}
              </h2>
            </div>
            <ul className="space-y-1.5 text-[11px] px-1" dir={isAr ? 'rtl' : 'ltr'} style={{ color: '#334155' }}>
              {validCertifications.map((cert) => {
                const title = isAr ? cert.titleAr : cert.titleEn;
                const issuer = isAr ? cert.issuerAr : cert.issuerEn;
                return (
                  <li key={cert.id} className="cv-item flex items-start gap-1.5 leading-normal">
                    <span className="shrink-0 text-[10px] font-bold" style={{ color: '#d97706' }}>✓</span>
                    <span className="flex-1">
                      {title && <strong style={{ color: '#0f172a' }}>{title}</strong>}
                      {issuer && <span className="text-[10px] block text-slate-500">{issuer} {cert.year ? `(${cert.year})` : ''}</span>}
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>
        )}

        {validLanguages.length > 0 && (
          <section className="cv-section" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
            <div className="flex items-center gap-2 mb-2 border-b pb-1" style={{ borderColor: '#fef3c7' }}>
              <div className="w-1.5 h-3.5 rounded-full" style={{ backgroundColor: '#d97706' }}></div>
              <h2 className="text-xs font-extrabold uppercase tracking-wider" style={{ color: '#0f172a' }}>
                {isAr ? 'إتقان اللغات' : 'LANGUAGES'}
              </h2>
            </div>
            <div className="cv-item flex flex-wrap gap-2 text-[11px] px-1 font-medium">
              {validLanguages.map((langItem, idx) => {
                const name = isAr ? langItem.languageAr : langItem.languageEn;
                const level = isAr ? langItem.levelAr : langItem.levelEn;
                return (
                  <div key={idx} className="cv-badge inline-block px-2.5 py-1 rounded bg-slate-100 border border-slate-200 leading-snug align-middle">
                    <strong style={{ color: '#0f172a' }}>{name}:</strong>{' '}
                    <span style={{ color: '#475569' }}>{level}</span>
                  </div>
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
