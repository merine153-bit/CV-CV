import React from 'react';

interface CvLogoProps {
  className?: string;
  size?: number;
}

export const CvLogo: React.FC<CvLogoProps> = ({ className = '', size = 36 }) => {
  return (
    <div 
      className={`relative flex items-center justify-center rounded-xl bg-slate-950 border border-slate-800 p-1.5 shadow-md shadow-emerald-500/10 overflow-hidden group ${className}`}
      style={{ width: size, height: size }}
    >
      <div className="absolute inset-0 bg-emerald-500/10 blur-sm rounded-xl" />
      <svg
        viewBox="0 0 512 512"
        className="w-full h-full relative z-10 drop-shadow-[0_0_6px_rgba(16,185,129,0.8)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="cv-neon-grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4ade80" />
            <stop offset="100%" stopColor="#10b981" />
          </linearGradient>
        </defs>
        {/* Letter C */}
        <path
          d="M 235 210 C 220 185 185 175 152 192 C 115 212 100 255 100 295 C 100 338 120 380 156 398 C 190 415 228 402 240 375"
          stroke="url(#cv-neon-grad)"
          strokeWidth="48"
          strokeLinecap="round"
        />
        {/* Letter V with stylized checkmark tip */}
        <path
          d="M 270 210 L 338 375 C 344 390 358 390 364 375 L 430 205 C 440 182 458 172 472 176"
          stroke="url(#cv-neon-grad)"
          strokeWidth="48"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};
