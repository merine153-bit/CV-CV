import React, { useRef, useState } from 'react';
import { CandidateProfile, Language, CvTemplateId, CV_TEMPLATES } from '../types';
import { Mail, Phone, MapPin, Printer, Download, Copy, Check, Sparkles, Building2, Calendar, RefreshCw, LayoutTemplate } from 'lucide-react';
import { generateAndDownloadPdf, openPrintWindow } from '../utils/pdfExport';
import { ClassicTemplate } from './templates/ClassicTemplate';
import { ExecutiveTemplate } from './templates/ExecutiveTemplate';
import { SidebarTemplate } from './templates/SidebarTemplate';
import { CorporateTemplate } from './templates/CorporateTemplate';
import { CompactTemplate } from './templates/CompactTemplate';

interface CvPreviewProps {
  profile: CandidateProfile;
  lang: Language;
  showPhoto: boolean;
  selectedTemplate?: CvTemplateId;
  onSelectTemplate?: (templateId: CvTemplateId) => void;
}

export const CvPreview: React.FC<CvPreviewProps> = ({
  profile,
  lang,
  showPhoto,
  selectedTemplate: externalTemplate,
  onSelectTemplate: externalOnSelect,
}) => {
  const isAr = lang === 'ar';
  const cvRef = useRef<HTMLDivElement>(null);
  const [internalTemplate, setInternalTemplate] = useState<CvTemplateId>('classic');
  const [copied, setCopied] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const activeTemplate = externalTemplate || internalTemplate;
  const handleSelectTemplate = (id: CvTemplateId) => {
    setInternalTemplate(id);
    if (externalOnSelect) {
      externalOnSelect(id);
    }
  };

  // Helper checks for non-empty sections
  const hasContactInfo = Boolean(profile.email?.trim() || profile.phone?.trim() || (isAr ? profile.addressAr : profile.addressEn)?.trim());
  const summaryText = isAr ? profile.summaryAr?.trim() : profile.summaryEn?.trim();
  const politicalRoleText = isAr ? profile.politicalRoleAr?.trim() : profile.politicalRoleEn?.trim();
  const hasSummary = Boolean(summaryText || politicalRoleText);

  const validExperiences = profile.experiences.filter(exp => {
    const role = isAr ? exp.roleAr : exp.roleEn;
    const company = isAr ? exp.companyAr : exp.companyEn;
    const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
    return Boolean(role?.trim() || company?.trim() || bullets.length > 0);
  });

  const validEducation = profile.education.filter(edu => {
    const degree = isAr ? edu.degreeAr : edu.degreeEn;
    const inst = isAr ? edu.institutionAr : edu.institutionEn;
    return Boolean(degree?.trim() || inst?.trim());
  });

  const validSkillCategories = profile.skillCategories.filter(cat => {
    const categoryName = isAr ? cat.categoryAr : cat.categoryEn;
    const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
    return Boolean(categoryName?.trim() || skills.length > 0);
  });

  const validCertifications = profile.certifications.filter(cert => {
    const title = isAr ? cert.titleAr : cert.titleEn;
    const issuer = isAr ? cert.issuerAr : cert.issuerEn;
    return Boolean(title?.trim() || issuer?.trim());
  });

  const validLanguages = profile.languages.filter(langItem => {
    const name = isAr ? langItem.languageAr : langItem.languageEn;
    return Boolean(name?.trim());
  });

  const handleDownloadPdf = async () => {
    setIsExportingPdf(true);
    const rawName = isAr ? profile.fullNameAr : profile.fullNameEn;
    const name = (rawName?.trim() || 'Resume').replace(/\s+/g, '_');
    const filename = `CV_${name}.pdf`;
    
    const success = await generateAndDownloadPdf('cv-printable-area', filename);
    if (!success) {
      openPrintWindow('cv-printable-area', `CV ${name}`);
    }
    setIsExportingPdf(false);
  };

  const handlePrint = () => {
    const name = isAr ? profile.fullNameAr : profile.fullNameEn;
    openPrintWindow('cv-printable-area', `CV ${name || 'Resume'}`);
  };

  const handleCopyText = () => {
    const textLines: string[] = [];
    
    // Header
    const name = isAr ? profile.fullNameAr : profile.fullNameEn;
    const title = isAr ? profile.titleAr : profile.titleEn;
    if (name) textLines.push(name);
    if (title) textLines.push(title);
    if (hasContactInfo) {
      textLines.push(`Email: ${profile.email} | Phone: ${profile.phone} | Location: ${isAr ? profile.addressAr : profile.addressEn}`);
    }
    textLines.push('\n--------------------------------------------------\n');
    
    // Summary
    if (hasSummary) {
      textLines.push(isAr ? 'الملف الشخصي / PROFESSIONAL SUMMARY:' : 'PROFESSIONAL SUMMARY:');
      if (summaryText) textLines.push(summaryText);
      if (politicalRoleText) textLines.push(politicalRoleText);
      textLines.push('\n--------------------------------------------------\n');
    }

    // Experience
    if (validExperiences.length > 0) {
      textLines.push(isAr ? 'الخبرة المهنية / WORK EXPERIENCE:' : 'WORK EXPERIENCE:');
      validExperiences.forEach(exp => {
        textLines.push(`${isAr ? exp.roleAr : exp.roleEn} | ${isAr ? exp.companyAr : exp.companyEn}`);
        textLines.push(`${exp.startDate} - ${exp.endDate} | ${isAr ? exp.locationAr : exp.locationEn}`);
        const bullets = (isAr ? exp.bulletsAr : exp.bulletsEn).filter(b => b && b.trim().length > 0);
        bullets.forEach(b => textLines.push(`• ${b}`));
        textLines.push('');
      });
      textLines.push('--------------------------------------------------\n');
    }

    // Education
    if (validEducation.length > 0) {
      textLines.push(isAr ? 'التعليم والشهادات الجامعية / EDUCATION:' : 'EDUCATION:');
      validEducation.forEach(edu => {
        textLines.push(`${isAr ? edu.degreeAr : edu.degreeEn} - ${isAr ? edu.institutionAr : edu.institutionEn} (${edu.startDate} - ${edu.endDate})`);
        if (isAr ? edu.detailsAr : edu.detailsEn) {
          textLines.push(`  ${isAr ? edu.detailsAr : edu.detailsEn}`);
        }
      });
      textLines.push('\n--------------------------------------------------\n');
    }

    // Skills
    if (validSkillCategories.length > 0) {
      textLines.push(isAr ? 'المهارات التقنية والشخصية / SKILLS:' : 'SKILLS:');
      validSkillCategories.forEach(cat => {
        const skills = (isAr ? cat.skillsAr : cat.skillsEn).filter(s => s && s.trim().length > 0);
        textLines.push(`${isAr ? cat.categoryAr : cat.categoryEn}: ${skills.join(', ')}`);
      });
      textLines.push('\n--------------------------------------------------\n');
    }

    // Certifications
    if (validCertifications.length > 0) {
      textLines.push(isAr ? 'الدورات والتكوينات / CERTIFICATIONS & TRAINING:' : 'CERTIFICATIONS & TRAINING:');
      validCertifications.forEach(cert => {
        textLines.push(`• ${isAr ? cert.titleAr : cert.titleEn} (${isAr ? cert.issuerAr : cert.issuerEn}${cert.year ? ` - ${cert.year}` : ''})`);
      });
      textLines.push('\n--------------------------------------------------\n');
    }

    // Languages
    if (validLanguages.length > 0) {
      textLines.push(isAr ? 'اللغات / LANGUAGES:' : 'LANGUAGES:');
      validLanguages.forEach(langItem => {
        textLines.push(`${isAr ? langItem.languageAr : langItem.languageEn}: ${isAr ? langItem.levelAr : langItem.levelEn}`);
      });
    }

    navigator.clipboard.writeText(textLines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const renderTemplateComponent = () => {
    switch (activeTemplate) {
      case 'executive':
        return <ExecutiveTemplate profile={profile} lang={lang} showPhoto={showPhoto} />;
      case 'sidebar':
        return <SidebarTemplate profile={profile} lang={lang} showPhoto={showPhoto} />;
      case 'corporate':
        return <CorporateTemplate profile={profile} lang={lang} showPhoto={showPhoto} />;
      case 'compact':
        return <CompactTemplate profile={profile} lang={lang} showPhoto={showPhoto} />;
      case 'classic':
      default:
        return <ClassicTemplate profile={profile} lang={lang} showPhoto={showPhoto} />;
    }
  };

  return (
    <div className="space-y-4">
      {/* 5 Templates Selection Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-2.5 print:hidden shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
            <LayoutTemplate className="w-4 h-4 text-amber-400" />
            <span>{isAr ? 'اختر تصميم وقالب السيرة الذاتية (5 تصاميم احترافية):' : 'Select Resume Template (5 Designs):'}</span>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            {isAr ? 'متوافقة 100% مع الطباعة والتصدير' : '100% Print & PDF Ready'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {CV_TEMPLATES.map((tmpl) => {
            const isSelected = activeTemplate === tmpl.id;
            return (
              <button
                key={tmpl.id}
                onClick={() => handleSelectTemplate(tmpl.id)}
                className={`flex flex-col items-start p-2.5 rounded-lg text-start transition-all border ${
                  isSelected
                    ? 'bg-slate-800 border-indigo-500 shadow-md ring-1 ring-indigo-500/50'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${tmpl.badgeBg} ${tmpl.badgeText}`}>
                    {tmpl.id}
                  </span>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  )}
                </div>

                <span className={`text-xs font-extrabold line-clamp-1 ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {isAr ? tmpl.nameAr.split('(')[0] : tmpl.nameEn}
                </span>
                <span className="text-[10px] text-slate-400 line-clamp-1 mt-0.5 leading-tight">
                  {isAr ? tmpl.descriptionAr : tmpl.descriptionEn}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 print:hidden">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-300">
            {isAr ? 'معاينة المستند:' : 'Document View:'}
          </span>
          <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-medium">
            {showPhoto ? (isAr ? 'مع صورة' : 'Visual Mode') : (isAr ? 'بدون صورة' : 'Text Mode')}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyText}
            className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
            title={isAr ? 'نسخ النص الخالي من التنسيق' : 'Copy Plain Text'}
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{copied ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ النص' : 'Copy Text')}</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-all"
            title={isAr ? 'فتح نافذة الطباعة المباشرة' : 'Open Print Dialog'}
          >
            <Printer className="w-3.5 h-3.5 text-slate-300" />
            <span>{isAr ? 'طباعة' : 'Print'}</span>
          </button>

          <button
            onClick={handleDownloadPdf}
            disabled={isExportingPdf}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all"
            title={isAr ? 'تنزيل ملف السيرة الذاتية بصيغة PDF' : 'Download CV as PDF file'}
          >
            {isExportingPdf ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>{isAr ? 'جاري التحميل...' : 'Generating PDF...'}</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>{isAr ? 'تحميل ملف PDF' : 'Download PDF'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* The Printable / Rendered CV Sheet */}
      <div
        ref={cvRef}
        id="cv-printable-area"
        dir={isAr ? 'rtl' : 'ltr'}
        className={`bg-white text-slate-900 p-6 md:p-10 shadow-xl rounded-xl border-t-4 ${
          isAr ? 'border-emerald-600' : 'border-blue-600'
        } border-x border-b border-slate-200 max-w-4xl mx-auto font-sans leading-relaxed text-xs transition-all print:shadow-none print:rounded-none print:border-none ${
          isAr ? 'font-arabic' : ''
        }`}
        style={{
          minHeight: '1050px',
          paddingBottom: '40px',
          color: '#0f172a',
          backgroundColor: '#ffffff'
        }}
      >
        {renderTemplateComponent()}
      </div>
    </div>
  );
};

