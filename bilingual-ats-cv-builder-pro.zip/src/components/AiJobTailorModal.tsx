import React, { useState } from 'react';
import { Language, CandidateProfile } from '../types';
import { X, Sparkles, CheckCircle2, AlertCircle, Plus, RefreshCw, Wand2, Briefcase, Award, Check } from 'lucide-react';

interface AiJobTailorModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  profile: CandidateProfile;
  targetJobDescription: string;
  onUpdateTargetJobDescription: (jd: string) => void;
  onApplyTailoredSummary: (newSummary: string) => void;
  onApplySkills?: (skills: string[]) => void;
  onApplyBullets?: (bullets: string[]) => void;
  onApplyAllTailored?: (analysis: any) => void;
}

export const AiJobTailorModal: React.FC<AiJobTailorModalProps> = ({
  isOpen,
  onClose,
  lang,
  profile,
  targetJobDescription,
  onUpdateTargetJobDescription,
  onApplyTailoredSummary,
  onApplySkills,
  onApplyBullets,
  onApplyAllTailored,
}) => {
  const isAr = lang === 'ar';
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [appliedNotice, setAppliedNotice] = useState<string | null>(null);

  // States to track which items were applied locally
  const [appliedSummary, setAppliedSummary] = useState(false);
  const [appliedSkills, setAppliedSkills] = useState<Set<string>>(new Set());
  const [appliedBullets, setAppliedBullets] = useState<Set<string>>(new Set());

  if (!isOpen) return null;

  const handleAnalyze = async () => {
    if (!targetJobDescription.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    setAnalysisResult(null);
    setAppliedNotice(null);
    setAppliedSummary(false);
    setAppliedSkills(new Set());
    setAppliedBullets(new Set());

    try {
      const res = await fetch('/api/gemini/tailor-cv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobDescription: targetJobDescription,
          currentSummary: isAr ? profile.summaryAr : profile.summaryEn,
          profile,
          language: lang
        })
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || (isAr ? 'فشل تحليل الإعلان الوظيفي بواسطة الذكاء الاصطناعي' : 'Failed to analyze job description with AI'));
      }

      setAnalysisResult(data);
    } catch (err: any) {
      console.error('Job Tailor error:', err);
      setErrorMsg(err.message || (isAr ? 'حدث خطأ أثناء معالجة طلب المطابقة بالذكاء الاصطناعي' : 'Failed to generate tailored recommendations'));
    } finally {
      setLoading(false);
    }
  };

  const showFeedback = (msg: string) => {
    setAppliedNotice(msg);
    setTimeout(() => setAppliedNotice(null), 3500);
  };

  const handleApplySingleSkill = (skill: string) => {
    if (onApplySkills) {
      onApplySkills([skill]);
      setAppliedSkills(prev => new Set(prev).add(skill));
      showFeedback(isAr ? `تمت إضافة المهارة: "${skill}" إلى السيرة الذاتية` : `Added skill: "${skill}" to resume`);
    }
  };

  const handleApplyAllSkills = (skills: string[]) => {
    if (onApplySkills && skills.length > 0) {
      onApplySkills(skills);
      setAppliedSkills(prev => {
        const next = new Set(prev);
        skills.forEach(s => next.add(s));
        return next;
      });
      showFeedback(isAr ? `تمت إضافة ${skills.length} مهارات مفتاحية إلى السيرة الذاتية!` : `Added ${skills.length} skills to resume!`);
    }
  };

  const handleApplySingleBullet = (bullet: string) => {
    if (onApplyBullets) {
      onApplyBullets([bullet]);
      setAppliedBullets(prev => new Set(prev).add(bullet));
      showFeedback(isAr ? 'تمت إضافة نقطة الإنجاز إلى الخبرة العملية' : 'Added bullet point to experience history');
    }
  };

  const handleApplyAllBullets = (bullets: string[]) => {
    if (onApplyBullets && bullets.length > 0) {
      onApplyBullets(bullets);
      setAppliedBullets(prev => {
        const next = new Set(prev);
        bullets.forEach(b => next.add(b));
        return next;
      });
      showFeedback(isAr ? `تمت إضافة ${bullets.length} نقاط إنجاز جديدة إلى الخبرات!` : `Added ${bullets.length} bullet points to experience!`);
    }
  };

  const handleApplyMasterAll = () => {
    if (onApplyAllTailored && analysisResult) {
      onApplyAllTailored(analysisResult);
      onClose(); // Close modal immediately as requested
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">
            {isAr ? 'مُطابق السيرة الذاتية الذكي مع الإعلان الوظيفي (AI ATS Tailor)' : 'AI Multi-Section ATS Job Tailoring'}
          </h2>
        </div>

        <p className="text-xs text-slate-400 mb-5 leading-relaxed">
          {isAr
            ? 'قم بلصق نص الوصف الوظيفي. يقوم الذكاء الاصطناعي باستخراج الكلمات المفتاحية الناقصة، المهارات المطلوبة، صياغة ملخص موجه، ونقاط إنجاز احترافية يمكن إضافتها فوراً بنقرة زر إلى السيرة الذاتية.'
            : 'Paste any job description. Gemini AI will analyze the job posting and generate tailored recommendations for your Summary, Technical Skills, and Work Experience bullets with instant 1-click apply buttons.'}
        </p>

        {/* Feedback Alert Toast */}
        {appliedNotice && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{appliedNotice}</span>
          </div>
        )}

        {/* Error Alert Toast */}
        {errorMsg && (
          <div className="mb-4 p-3.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-semibold flex items-start gap-2 animate-fadeIn leading-relaxed">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <strong className="block font-bold mb-0.5">{isAr ? 'خطأ في عملية التوليد:' : 'AI Generation Error:'}</strong>
              <span>{errorMsg}</span>
            </div>
          </div>
        )}

        {/* Textarea for Job Description */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-1.5">
            {isAr ? 'نص الوصف الوظيفي / الإعلان الوظيفي المستهدف:' : 'Target Job Description Text:'}
          </label>
          <textarea
            rows={4}
            value={targetJobDescription}
            onChange={(e) => onUpdateTargetJobDescription(e.target.value)}
            placeholder={
              isAr
                ? 'مثال: مطلوب تقني تشغيل أو مهندس بتروكيماويات أو إطار صحي بالمسح الطبي والراديو لدى شركة سوناطراك أو المؤسسات الاستشفائية...'
                : 'Example: Seeking Operations Specialist / Process Engineer for Methanol petrochemical plant with safety HSE knowledge and DCS monitoring...'
            }
            className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed"
          />
        </div>

        <button
          onClick={handleAnalyze}
          disabled={loading || !targetJobDescription.trim()}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all mb-6"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
              <span>{isAr ? 'جاري التحليل والمطابقة لكل الأقسام...' : 'Analyzing & Tailoring all sections with AI...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isAr ? 'توليد التوصيات والخصائص المخصصة بالذكاء الاصطناعي' : 'Generate Full Tailored CV Sections'}</span>
            </>
          )}
        </button>

        {/* Results view */}
        {analysisResult && (
          <div className="space-y-5 pt-4 border-t border-slate-800 animate-fadeIn">
            
            {/* Top Summary Banner & One-Click Apply All */}
            <div className="p-4 bg-slate-800/90 border border-slate-700 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-xs text-slate-400 font-medium block mb-1">
                  {isAr ? 'نسبة مطابقة السيرة الذاتية مع الإعلان:' : 'Overall ATS Job Match:'}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-black text-emerald-400">
                    {analysisResult.matchPercentage || 85}%
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                    {isAr ? 'جاهزية خوارزمية عالية' : 'High ATS Compatibility'}
                  </span>
                </div>
              </div>

              {onApplyAllTailored && (
                <button
                  onClick={handleApplyMasterAll}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all shrink-0"
                >
                  <Wand2 className="w-4 h-4 text-amber-300" />
                  <span>{isAr ? 'تطبيق جميع التوصيات في السيرة الذاتية (بنقرة واحدة)' : 'Apply All Tailored Improvements (1-Click)'}</span>
                </button>
              )}
            </div>

            {/* 1. Tailored Summary */}
            {analysisResult.suggestedSummary && (
              <div className="p-4 bg-indigo-950/40 border border-indigo-500/30 rounded-xl space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>{isAr ? '1. الملخص المهني المخصص (Tailored Summary):' : '1. Tailored Professional Summary:'}</span>
                  </span>

                  <button
                    onClick={() => {
                      onApplyTailoredSummary(analysisResult.suggestedSummary);
                      setAppliedSummary(true);
                      showFeedback(isAr ? 'تم تطبيق الملخص المهني في السيرة الذاتية' : 'Applied summary to resume');
                    }}
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
                      appliedSummary
                        ? 'bg-emerald-600 text-white border border-emerald-400'
                        : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                    }`}
                  >
                    {appliedSummary ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تمت الإضافة ✓' : 'Added ✓'}</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تطبيق الملخص في السيرة الذاتية' : 'Apply Summary to Resume'}</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed italic bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                  "{analysisResult.suggestedSummary}"
                </p>
              </div>
            )}

            {/* 2. Suggested Skills & Keywords */}
            {((analysisResult.suggestedSkills && analysisResult.suggestedSkills.length > 0) ||
              (analysisResult.missingKeywords && analysisResult.missingKeywords.length > 0)) && (() => {
                const allSkills = Array.from(new Set([
                  ...(analysisResult.suggestedSkills || []),
                  ...(analysisResult.missingKeywords || [])
                ]));
                const areAllApplied = allSkills.every(s => appliedSkills.has(s));

                return (
                  <div className="p-4 bg-slate-800/60 border border-slate-700/80 rounded-xl space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <Award className="w-4 h-4 text-amber-400" />
                        <span>{isAr ? '2. المهارات والكلمات المفتاحية المطلوبة:' : '2. Key Technical Skills & Recommended Keywords:'}</span>
                      </span>

                      {onApplySkills && (
                        <button
                          onClick={() => handleApplyAllSkills(allSkills)}
                          className={`px-3 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
                            areAllApplied
                              ? 'bg-emerald-600 text-white border border-emerald-400'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                          }`}
                        >
                          {areAllApplied ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              <span>{isAr ? 'تمت إضافة جميع المهارات ✓' : 'All Skills Added ✓'}</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>{isAr ? 'إضافة جميع المهارات والكلمات إلى السيرة الذاتية' : 'Add All Skills & Keywords'}</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2 pt-1">
                      {allSkills.map((skillStr: string, idx: number) => {
                        const isSkillApplied = appliedSkills.has(skillStr);
                        return (
                          <div
                            key={idx}
                            className={`inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-lg text-xs leading-none transition-all ${
                              isSkillApplied
                                ? 'bg-emerald-950/70 border border-emerald-500/80 text-emerald-200 font-bold shadow-sm shadow-emerald-900/30'
                                : 'bg-indigo-900/40 border border-indigo-700/60 text-indigo-200 font-medium'
                            }`}
                            style={{ lineHeight: '1' }}
                          >
                            <span className="inline-flex items-center justify-center leading-none text-center relative -top-[1.5px]">{skillStr}</span>
                            {onApplySkills && (
                              <button
                                onClick={() => handleApplySingleSkill(skillStr)}
                                className={`p-0.5 rounded transition-all ${
                                  isSkillApplied
                                    ? 'bg-emerald-500/30 text-emerald-300'
                                    : 'bg-indigo-500/20 hover:bg-emerald-600 hover:text-white text-indigo-300'
                                }`}
                                title={isSkillApplied ? (isAr ? 'تمت إضافة هذه المهارة' : 'Skill added') : (isAr ? 'إضافة هذه المهارة للسيرة الذاتية' : 'Add skill to resume')}
                              >
                                {isSkillApplied ? (
                                  <Check className="w-3 h-3 text-emerald-400 font-bold" />
                                ) : (
                                  <Plus className="w-3 h-3" />
                                )}
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}

            {/* 3. Tailored Experience Bullets */}
            {analysisResult.suggestedBullets && analysisResult.suggestedBullets.length > 0 && (() => {
              const bullets: string[] = analysisResult.suggestedBullets;
              const areAllBulletsApplied = bullets.every(b => appliedBullets.has(b));

              return (
                <div className="p-4 bg-slate-800/60 border border-slate-700/80 rounded-xl space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs font-bold text-sky-300 flex items-center gap-1.5">
                      <Briefcase className="w-4 h-4 text-sky-400" />
                      <span>{isAr ? '3. نقاط الإنجاز المقترحة للخبرة العملية (Bullets with Action Verbs):' : '3. Tailored Experience Bullet Points:'}</span>
                    </span>

                    {onApplyBullets && (
                      <button
                        onClick={() => handleApplyAllBullets(bullets)}
                        className={`px-3 py-1.5 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
                          areAllBulletsApplied
                            ? 'bg-emerald-600 text-white border border-emerald-400'
                            : 'bg-sky-600 hover:bg-sky-500 text-white'
                        }`}
                      >
                        {areAllBulletsApplied ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تمت إضافة كل النقاط ✓' : 'All Bullets Added ✓'}</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>{isAr ? 'إضافة كل النقاط للخبرة العملية' : 'Add All Bullets to Experience'}</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  <div className="space-y-2 pt-1">
                    {bullets.map((bulletStr: string, idx: number) => {
                      const isBulletApplied = appliedBullets.has(bulletStr);
                      return (
                        <div
                          key={idx}
                          className={`p-3 rounded-lg text-xs flex items-start justify-between gap-3 leading-relaxed transition-all ${
                            isBulletApplied
                              ? 'bg-emerald-950/40 border border-emerald-500/60 text-emerald-100 font-medium shadow-sm shadow-emerald-950/30'
                              : 'bg-slate-900/80 border border-slate-700/70 text-slate-200'
                          }`}
                        >
                          <span className="flex-1">• {bulletStr}</span>
                          {onApplyBullets && (
                            <button
                              onClick={() => handleApplySingleBullet(bulletStr)}
                              className={`px-2.5 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 shrink-0 transition-all ${
                                isBulletApplied
                                  ? 'bg-emerald-600 border border-emerald-400 text-white shadow-md'
                                  : 'bg-emerald-600/30 hover:bg-emerald-600 text-emerald-200 hover:text-white border border-emerald-500/40'
                              }`}
                            >
                              {isBulletApplied ? (
                                <>
                                  <Check className="w-3 h-3" />
                                  <span>{isAr ? 'تمت الإضافة ✓' : 'Added ✓'}</span>
                                </>
                              ) : (
                                <>
                                  <Plus className="w-3 h-3" />
                                  <span>{isAr ? 'إضافة' : 'Add'}</span>
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })()}

            {/* 4. Actionable Tips */}
            {analysisResult.actionableTips && analysisResult.actionableTips.length > 0 && (
              <div className="p-3 bg-indigo-950/20 border border-indigo-500/20 rounded-xl space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>{isAr ? 'نصائح تحسين إضافية لزيادة الجاهزية:' : 'Additional Recommendations:'}</span>
                </div>
                <ul className="list-disc list-inside text-[11px] text-slate-300 space-y-1 pl-2">
                  {analysisResult.actionableTips.map((tip: string, i: number) => (
                    <li key={i}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
};
