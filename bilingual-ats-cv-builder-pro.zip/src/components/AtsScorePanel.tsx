import React from 'react';
import { AtsScoreAnalysis, Language } from '../types';
import { CheckCircle2, AlertTriangle, Info, Sparkles, Shield, Zap, FileCheck } from 'lucide-react';

interface AtsScorePanelProps {
  analysis: AtsScoreAnalysis;
  lang: Language;
  onOpenTailorModal: () => void;
}

export const AtsScorePanel: React.FC<AtsScorePanelProps> = ({
  analysis,
  lang,
  onOpenTailorModal,
}) => {
  const isAr = lang === 'ar';

  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30';
    if (score >= 70) return 'text-amber-500 bg-amber-500/10 border-amber-500/30';
    return 'text-rose-500 bg-rose-500/10 border-rose-500/30';
  };

  const getGaugeBg = (score: number) => {
    if (score >= 85) return 'from-emerald-500 to-teal-600';
    if (score >= 70) return 'from-amber-500 to-orange-500';
    return 'from-rose-500 to-red-600';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl p-5 shadow-xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-5 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-400" />
            <h2 className="font-bold text-lg text-white">
              {isAr ? 'مؤشر مطابقة ATS المباشر' : 'Live ATS Scanner & Score'}
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr
              ? 'تحليل الملاءمة مع أنظمة التوظيف الآلية (Workday, Taleo, Greenhouse, iCIMS)'
              : 'Real-time ATS parsing audit against top corporate tracking systems'}
          </p>
        </div>

        <button
          onClick={onOpenTailorModal}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-medium text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/25 transition-all"
        >
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          {isAr ? 'مطابقة مع إعلان وظيفي (AI)' : 'Match Target Job Description (AI)'}
        </button>
      </div>

      {/* Top Gauge & Score Bar */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-5">
        <div className="md:col-span-2 bg-slate-800/60 rounded-xl p-4 border border-slate-700/50 flex items-center justify-around">
          <div className="relative flex items-center justify-center w-24 h-24">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-700"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="text-indigo-500 transition-all duration-1000 ease-out"
                strokeDasharray={`${analysis.score}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-2xl font-black text-white">{analysis.score}%</span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                {isAr ? 'نسبة القبول' : 'ATS Score'}
              </span>
            </div>
          </div>

          <div className="space-y-1 text-xs">
            <div className="text-slate-300 font-semibold">
              {analysis.score >= 85
                ? (isAr ? 'ممتاز (جاهز للـ ATS)' : 'High Compatibility')
                : analysis.score >= 70
                ? (isAr ? 'جيد جداً (تحسينات بسيطة)' : 'Good Compatibility')
                : (isAr ? 'يحتاج تحسين' : 'Needs Optimization')}
            </div>
            <div className="text-slate-400 text-[11px] max-w-[140px] leading-tight">
              {isAr
                ? 'تنسيق قياسي بنسبة 100% بدون أخطاء قراءة'
                : 'Clean single-column parsing & bullet structure'}
            </div>
          </div>
        </div>

        {/* Category Breakdown */}
        <div className="md:col-span-3 grid grid-cols-2 gap-2.5">
          <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-700/40">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">{isAr ? 'التنسيق والهيكلة' : 'Formatting & Parsability'}</span>
              <span className="font-bold text-emerald-400">{analysis.formattingScore}%</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full transition-all" style={{ width: `${analysis.formattingScore}%` }} />
            </div>
          </div>

          <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-700/40">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">{isAr ? 'الكلمات المفتاحية' : 'Domain Keywords'}</span>
              <span className="font-bold text-indigo-400">{analysis.keywordScore}%</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-indigo-500 h-full transition-all" style={{ width: `${analysis.keywordScore}%` }} />
            </div>
          </div>

          <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-700/40">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">{isAr ? 'أفعال الإنجاز القوية' : 'Action Verbs Power'}</span>
              <span className="font-bold text-violet-400">{analysis.actionVerbScore}%</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-violet-500 h-full transition-all" style={{ width: `${analysis.actionVerbScore}%` }} />
            </div>
          </div>

          <div className="bg-slate-800/40 p-2.5 rounded-lg border border-slate-700/40">
            <div className="flex justify-between items-center text-xs mb-1">
              <span className="text-slate-400">{isAr ? 'اكتمال الأقسام' : 'Section Completeness'}</span>
              <span className="font-bold text-teal-400">{analysis.completenessScore}%</span>
            </div>
            <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-teal-500 h-full transition-all" style={{ width: `${analysis.completenessScore}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Strong Action Verbs Found */}
      {analysis.strongVerbsFound.length > 0 && (
        <div className="mb-4 bg-slate-800/30 p-3 rounded-xl border border-slate-700/30">
          <div className="flex items-center gap-1.5 mb-2 text-xs font-semibold text-slate-300">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'الأفعال القيادية والأدوار المؤثرة المكتشفة:' : 'High-Impact Action Verbs Found:'}</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {analysis.strongVerbsFound.map((verb, idx) => (
              <span key={idx} className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[11px] px-2 py-0.5 rounded-md font-medium">
                {verb}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Feedback Checklist */}
      <div className="space-y-2">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
          {isAr ? 'توصيات تحسين الأداء:' : 'Optimization Checklist:'}
        </h4>
        {analysis.feedback.map((item, idx) => (
          <div key={idx} className="flex items-start gap-2 text-xs p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/30">
            {item.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />}
            {item.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />}
            {item.type === 'info' && <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />}
            <span className="text-slate-300">{isAr ? item.messageAr : item.messageEn}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
