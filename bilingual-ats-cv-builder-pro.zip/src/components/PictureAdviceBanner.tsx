import React, { useState } from 'react';
import { Camera, CheckCircle2, AlertTriangle, Info, X } from 'lucide-react';
import { Language } from '../types';

interface PictureAdviceBannerProps {
  lang: Language;
  hasPhoto: boolean;
  onTogglePhoto: (enable: boolean) => void;
}

export const PictureAdviceBanner: React.FC<PictureAdviceBannerProps> = ({
  lang,
  hasPhoto,
  onTogglePhoto,
}) => {
  const [dismissed, setDismissed] = useState(false);
  const isAr = lang === 'ar';

  if (dismissed) return null;

  return (
    <div className={`mb-6 p-5 rounded-xl border ${hasPhoto ? 'bg-amber-500/10 border-amber-500/30' : 'bg-emerald-500/10 border-emerald-500/30'} shadow-sm relative transition-all`}>
      <button
        onClick={() => setDismissed(true)}
        className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-full"
        title={isAr ? 'إغلاق' : 'Dismiss'}
      >
        <X className="w-4 h-4" />
      </button>

      <div className="flex flex-col sm:flex-row items-start gap-4">
        <div className={`p-3 rounded-lg ${hasPhoto ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400' : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'} shrink-0`}>
          <Camera className="w-6 h-6" />
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">
              {isAr
                ? 'هل تحتاج إلى إضافة صورتك الشخصية في سيرتك الذاتية للـ ATS؟'
                : 'Do you need your picture for a High ATS Score?'}
            </h3>
            <span className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${hasPhoto ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300' : 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'}`}>
              {hasPhoto
                ? (isAr ? 'وضع العرض البصري (مع صورة)' : 'Visual Mode (Photo Enabled)')
                : (isAr ? 'وضع ATS المعياري (بدون صورة - موصى به)' : 'Strict ATS Standard (No Photo - Recommended)')}
            </span>
          </div>

          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-3">
            {isAr ? (
              <>
                <strong className="text-emerald-600 dark:text-emerald-400">الجواب المباشر: لا! </strong>
                أنظمة تتبع المتقدمين للوظائف (Workday, Taleo, Greenhouse, iCIMS) تُفضل السير الذاتية الخالية تماماً من الصور والتصاميم المزدوجة الأعمدة، لأن الصور قد تتسبب في أخطاء القراءة الآلية أو استبعاد الملف تلقائياً وفقاً لمعايير التوظيف العالمية.
              </>
            ) : (
              <>
                <strong className="text-emerald-600 dark:text-emerald-400">Direct Answer: NO! </strong>
                Applicant Tracking Systems (Workday, Taleo, Greenhouse, iCIMS) parse raw text. Photos can corrupt text extraction, cause misalignment, or trigger automatic filtering. We recommend keeping photos OFF for direct online job applications.
              </>
            )}
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onTogglePhoto(false)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                !hasPhoto
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              {isAr ? 'تفعيل وضع ATS القياسي (بدون صورة - 100% مطابقة)' : 'Use Strict ATS Mode (No Photo - 100% Match)'}
            </button>

            <button
              onClick={() => onTogglePhoto(true)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                hasPhoto
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              {isAr ? 'تفعيل الوضع البصري (مع صورة للتقديم المباشر أو الطباعة)' : 'Enable Photo Mode (For Direct Email / Print)'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
