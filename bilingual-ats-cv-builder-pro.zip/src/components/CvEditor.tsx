import React, { useState, useEffect } from 'react';
import { CandidateProfile, Language, WorkExperience, Education, Certification, SkillCategory } from '../types';
import { blankProfile, sampleProfile } from '../data/initialProfile';
import { 
  Sparkles, Plus, Trash2, Edit3, User, Briefcase, 
  GraduationCap, Award, Wrench, Languages as LangIcon, 
  RefreshCw, Wand2, RotateCcw, FileText
} from 'lucide-react';

interface SkillTextInputProps {
  skills: string[];
  onChange: (skills: string[]) => void;
  placeholder: string;
  dir?: 'rtl' | 'ltr';
  separator?: string;
}

const SkillTextInput: React.FC<SkillTextInputProps> = ({
  skills,
  onChange,
  placeholder,
  dir = 'ltr',
  separator = ', '
}) => {
  const [val, setVal] = useState<string>(() => (skills || []).filter(Boolean).join(separator));

  const joinedSkills = (skills || []).filter(Boolean).join(separator);

  useEffect(() => {
    setVal(joinedSkills);
  }, [joinedSkills]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setVal(raw);

    const parsed = raw
      .split(/[،,]/)
      .map(s => s.trim())
      .filter(Boolean);

    onChange(parsed);
  };

  return (
    <input
      type="text"
      placeholder={placeholder}
      value={val}
      onChange={handleChange}
      className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
      dir={dir}
    />
  );
};

interface CvEditorProps {
  profile: CandidateProfile;
  onChangeProfile: (newProfile: CandidateProfile) => void;
  lang: Language;
}

export const CvEditor: React.FC<CvEditorProps> = ({ profile, onChangeProfile, lang }) => {
  const isAr = lang === 'ar';
  const [activeTab, setActiveTab] = useState<'personal' | 'summary' | 'experience' | 'education' | 'skills' | 'certifications' | 'languages'>('personal');
  const [enhancingBulletId, setEnhancingBulletId] = useState<string | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [targetExpId, setTargetExpId] = useState<string | null>(null);
  const [targetBulletIndex, setTargetBulletIndex] = useState<number | null>(null);

  // General field update helper
  const updateField = (field: keyof CandidateProfile, value: any) => {
    onChangeProfile({
      ...profile,
      [field]: value
    });
  };

  // Clear Form / Load Sample helpers
  const handleClearForm = () => {
    if (window.confirm(isAr ? 'هل أنت تأكد من مسح وتفريغ كافة البيانات والبدء من جديد؟' : 'Clear all fields and start blank?')) {
      onChangeProfile(blankProfile);
    }
  };

  const handleLoadSample = () => {
    if (window.confirm(isAr ? 'هل تريد تحميل نموذج سيرة ذاتية تجريبية مليئة بالبيانات؟' : 'Load sample profile data into editor?')) {
      onChangeProfile(sampleProfile);
    }
  };

  // Enhance bullet point using Express server API (/api/gemini/enhance-bullets)
  const handleEnhanceBullet = async (expId: string, bulletIdx: number, originalBullet: string, roleTitle: string) => {
    setEnhancingBulletId(`${expId}-${bulletIdx}`);
    setTargetExpId(expId);
    setTargetBulletIndex(bulletIdx);
    setAiSuggestions([]);

    try {
      const res = await fetch('/api/gemini/enhance-bullets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bullet: originalBullet,
          language: lang,
          jobTitle: roleTitle
        })
      });

      const data = await res.json();
      if (data.result) {
        try {
          const parsed = JSON.parse(data.result);
          if (Array.isArray(parsed)) {
            setAiSuggestions(parsed);
          } else {
            setAiSuggestions(data.result.split('\n').filter((l: string) => l.trim().length > 5));
          }
        } catch (e) {
          setAiSuggestions(data.result.split('\n').filter((l: string) => l.trim().length > 5));
        }
      }
    } catch (err) {
      console.error('Enhance bullet error:', err);
    } finally {
      setEnhancingBulletId(null);
    }
  };

  const applySuggestion = (suggestion: string) => {
    if (!targetExpId || targetBulletIndex === null) return;

    const updatedExperiences = profile.experiences.map((exp) => {
      if (exp.id === targetExpId) {
        const bullets = [...(isAr ? exp.bulletsAr : exp.bulletsEn)];
        bullets[targetBulletIndex] = suggestion.replace(/^[-•*\d.]+\s*/, '').trim();
        return {
          ...exp,
          [isAr ? 'bulletsAr' : 'bulletsEn']: bullets
        };
      }
      return exp;
    });

    onChangeProfile({
      ...profile,
      experiences: updatedExperiences
    });

    setAiSuggestions([]);
    setTargetExpId(null);
    setTargetBulletIndex(null);
  };

  // --- Experience Helpers ---
  const addExperience = () => {
    const newExp: WorkExperience = {
      id: `exp-${Date.now()}`,
      companyEn: 'Company / Organization Name',
      companyAr: 'اسم الشركة / المؤسسة',
      roleEn: 'Job Title / Position',
      roleAr: 'المسمى الوظيفي',
      startDate: '2023',
      endDate: 'Present',
      locationEn: 'City, Country',
      locationAr: 'المدينة، الدولة',
      bulletsEn: ['Achieved key milestones by leading unit operations.'],
      bulletsAr: ['إنجاز المهام المسندة والتنسيق مع فريق العمل للوصول إلى الأهداف.']
    };
    onChangeProfile({
      ...profile,
      experiences: [newExp, ...profile.experiences]
    });
  };

  const removeExperience = (id: string) => {
    onChangeProfile({
      ...profile,
      experiences: profile.experiences.filter(e => e.id !== id)
    });
  };

  const addExperienceBullet = (expId: string) => {
    const updated = profile.experiences.map(exp => {
      if (exp.id === expId) {
        return {
          ...exp,
          bulletsAr: [...exp.bulletsAr, 'نقطة إنجاز جديدة...'],
          bulletsEn: [...exp.bulletsEn, 'New key responsibility...']
        };
      }
      return exp;
    });
    onChangeProfile({ ...profile, experiences: updated });
  };

  const removeExperienceBullet = (expId: string, bulletIdx: number) => {
    const updated = profile.experiences.map(exp => {
      if (exp.id === expId) {
        const bulletsAr = exp.bulletsAr.filter((_, idx) => idx !== bulletIdx);
        const bulletsEn = exp.bulletsEn.filter((_, idx) => idx !== bulletIdx);
        return { ...exp, bulletsAr, bulletsEn };
      }
      return exp;
    });
    onChangeProfile({ ...profile, experiences: updated });
  };

  // --- Education Helpers ---
  const addEducation = () => {
    const newEdu: Education = {
      id: `edu-${Date.now()}`,
      degreeAr: 'المؤهل العلمي / الشهادة الجامعية',
      degreeEn: 'Degree / University Qualification',
      institutionAr: 'اسم الجامعة / المعهد',
      institutionEn: 'University / Institute Name',
      startDate: '2020',
      endDate: '2024',
      detailsAr: 'تفاصيل التخصص والإنجازات الأكاديمية...',
      detailsEn: 'Specialization and academic focus...'
    };
    onChangeProfile({
      ...profile,
      education: [...profile.education, newEdu]
    });
  };

  const removeEducation = (id: string) => {
    onChangeProfile({
      ...profile,
      education: profile.education.filter(e => e.id !== id)
    });
  };

  // --- Skill Category Helpers ---
  const addSkillCategory = () => {
    const newCat: SkillCategory = {
      id: `cat-${Date.now()}`,
      categoryAr: 'تصنيف مهارات جديد',
      categoryEn: 'New Skill Category',
      skillsAr: ['مهارة 1', 'مهارة 2'],
      skillsEn: ['Skill 1', 'Skill 2']
    };
    onChangeProfile({
      ...profile,
      skillCategories: [...profile.skillCategories, newCat]
    });
  };

  const removeSkillCategory = (id: string) => {
    onChangeProfile({
      ...profile,
      skillCategories: profile.skillCategories.filter(c => c.id !== id)
    });
  };

  // --- Certification Helpers ---
  const addCertification = () => {
    const newCert: Certification = {
      id: `cert-${Date.now()}`,
      titleAr: 'اسم الشهادة أو الدورة التدريبية',
      titleEn: 'Course or Certification Title',
      issuerAr: 'الجهة المانحة / المعهد',
      issuerEn: 'Issuing Body / Organization',
      year: '2024'
    };
    onChangeProfile({
      ...profile,
      certifications: [...profile.certifications, newCert]
    });
  };

  const removeCertification = (id: string) => {
    onChangeProfile({
      ...profile,
      certifications: profile.certifications.filter(c => c.id !== id)
    });
  };

  // --- Language Helpers ---
  const addLanguage = () => {
    const newLang = {
      languageAr: 'لغة جديدة',
      languageEn: 'New Language',
      levelAr: 'مستوى متمكن',
      levelEn: 'Professional Proficiency'
    };
    onChangeProfile({
      ...profile,
      languages: [...profile.languages, newLang]
    });
  };

  const removeLanguage = (index: number) => {
    onChangeProfile({
      ...profile,
      languages: profile.languages.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Editor Header & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <h2 className="font-bold text-lg text-white flex items-center gap-2">
            <Edit3 className="w-5 h-5 text-indigo-400" />
            <span>{isAr ? 'محرر ومولد السيرة الذاتية' : 'CV Builder & Editor'}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {isAr ? 'عَبّئ بياناتك بحرية باللغتين العربية والإنجليزية لإنشاء CV احترافي' : 'Fill out your profile in English & Arabic for ATS parsers'}
          </p>
        </div>

        {/* Form Utilities: Blank vs Sample */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleClearForm}
            className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700/80 text-xs font-medium flex items-center gap-1.5 transition-all"
            title={isAr ? 'تفريغ كافة الخانات والبدء من جديد' : 'Clear form fields'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'تفريغ الخانات' : 'Clear Form'}</span>
          </button>

          <button
            onClick={handleLoadSample}
            className="px-2.5 py-1.5 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-700/50 text-xs font-medium flex items-center gap-1.5 transition-all"
            title={isAr ? 'تحميل نموذج سيرة ذاتية تجريبية' : 'Load sample profile'}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isAr ? 'نموذج تجريبي' : 'Load Sample'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 pb-2 border-b border-slate-800/80 no-scrollbar">
        <button
          onClick={() => setActiveTab('personal')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'personal' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>{isAr ? 'البيانات الشخصية' : 'Personal Info'}</span>
        </button>

        <button
          onClick={() => setActiveTab('summary')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'summary' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{isAr ? 'الملخص المهني' : 'Summary'}</span>
        </button>

        <button
          onClick={() => setActiveTab('experience')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'experience' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Briefcase className="w-3.5 h-3.5" />
          <span>{isAr ? 'الخبرات المهنية' : 'Experience'} ({profile.experiences.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('education')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'education' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5" />
          <span>{isAr ? 'المؤهلات والشهادات' : 'Education'} ({profile.education.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('skills')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'skills' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          <span>{isAr ? 'المهارات والكفاءات' : 'Skills'} ({profile.skillCategories.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('certifications')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'certifications' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>{isAr ? 'الدورات والتكوينات' : 'Certifications'} ({profile.certifications.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('languages')}
          className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-all ${
            activeTab === 'languages' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-800/60 text-slate-400 hover:text-slate-200'
          }`}
        >
          <LangIcon className="w-3.5 h-3.5" />
          <span>{isAr ? 'اللغات' : 'Languages'} ({profile.languages.length})</span>
        </button>
      </div>

      {/* Tab 1: Personal Info */}
      {activeTab === 'personal' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الاسم الكامل بالإنجليزية' : 'Full Name (English)'}
            </label>
            <input
              type="text"
              placeholder="e.g. John Doe"
              value={profile.fullNameEn}
              onChange={(e) => updateField('fullNameEn', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الاسم الكامل بالعربية' : 'Full Name (Arabic)'}
            </label>
            <input
              type="text"
              placeholder="مثال: محمد أحمد"
              value={profile.fullNameAr}
              onChange={(e) => updateField('fullNameAr', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              dir="rtl"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'المسمى الوظيفي المستهدف (إنجليزية)' : 'Target Job Title (English)'}
            </label>
            <input
              type="text"
              placeholder="e.g. Senior Software Engineer / Process Engineer"
              value={profile.titleEn}
              onChange={(e) => updateField('titleEn', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'المسمى الوظيفي المستهدف (عربية)' : 'Target Job Title (Arabic)'}
            </label>
            <input
              type="text"
              placeholder="مثال: مهندس برمجيات / تقني تشغيل منشآت"
              value={profile.titleAr}
              onChange={(e) => updateField('titleAr', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              dir="rtl"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'البريد الإلكتروني' : 'Email Address'}
            </label>
            <input
              type="email"
              placeholder="example@email.com"
              value={profile.email}
              onChange={(e) => updateField('email', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'رقم الهاتف' : 'Phone Number'}
            </label>
            <input
              type="text"
              placeholder="+213 555 123 456"
              value={profile.phone}
              onChange={(e) => updateField('phone', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              dir="ltr"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'العنوان والموقع (إنجليزية)' : 'Location (English)'}
            </label>
            <input
              type="text"
              placeholder="e.g. Oran, Algeria"
              value={profile.addressEn}
              onChange={(e) => updateField('addressEn', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'العنوان والموقع (عربية)' : 'Location (Arabic)'}
            </label>
            <input
              type="text"
              placeholder="مثال: وهران، الجزائر"
              value={profile.addressAr}
              onChange={(e) => updateField('addressAr', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              dir="rtl"
            />
          </div>
        </div>
      )}

      {/* Tab 2: Summary */}
      {activeTab === 'summary' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الملخص المهني بالإنجليزية (ATS Summary)' : 'Professional Summary (English)'}
            </label>
            <textarea
              rows={4}
              placeholder="Write a concise 3-4 sentence professional summary highlighting your key background, years of experience, and main domain skills..."
              value={profile.summaryEn}
              onChange={(e) => updateField('summaryEn', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-indigo-500 leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الملخص المهني بالعربية (ATS Summary)' : 'Professional Summary (Arabic)'}
            </label>
            <textarea
              rows={4}
              placeholder="اكتب ملخصاً مهنياً موجزاً يبرز سنوات خبرتك، مؤهلاتك العلمية وأهم مهاراتك الميدانية..."
              value={profile.summaryAr}
              onChange={(e) => updateField('summaryAr', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-indigo-500 leading-relaxed"
              dir="rtl"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الصفة أو التعيين المؤسساتي (إنجليزية - اختياري)' : 'Institutional Designation (English)'}
            </label>
            <input
              type="text"
              placeholder="Optional institutional title or council membership..."
              value={profile.politicalRoleEn || ''}
              onChange={(e) => updateField('politicalRoleEn', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isAr ? 'الصفة أو التعيين المؤسساتي (عربية - اختياري)' : 'Institutional Designation (Arabic)'}
            </label>
            <input
              type="text"
              placeholder="مثال: عضو مجلس مؤسساتي أو هيئة استشارية..."
              value={profile.politicalRoleAr || ''}
              onChange={(e) => updateField('politicalRoleAr', e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              dir="rtl"
            />
          </div>
        </div>
      )}

      {/* Tab 3: Work Experience */}
      {activeTab === 'experience' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">
              {isAr ? 'قائمة الخبرات والوظائف السابقة' : 'Work experience entries'}
            </span>
            <button
              onClick={addExperience}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة خبرة جديدة' : 'Add New Experience'}</span>
            </button>
          </div>

          {/* AI Suggestions Box */}
          {aiSuggestions.length > 0 && (
            <div className="p-4 bg-indigo-950/60 border border-indigo-500/40 rounded-xl text-xs space-y-2">
              <div className="flex items-center gap-2 text-indigo-300 font-bold">
                <Wand2 className="w-4 h-4 text-amber-300" />
                <span>{isAr ? 'اقتراحات الذكاء الاصطناعي (Gemini ATS Suggestions):' : 'AI Enhanced Bullet Options:'}</span>
              </div>
              <p className="text-[11px] text-slate-400">
                {isAr ? 'انقر على الاقتراح الأنسب لاستبدال النقطة المحددة تلقائياً:' : 'Click any suggestion to apply it:'}
              </p>
              <div className="space-y-1.5 pt-1">
                {aiSuggestions.map((sug, idx) => (
                  <button
                    key={idx}
                    onClick={() => applySuggestion(sug)}
                    className="w-full text-start p-2 rounded-lg bg-indigo-900/40 hover:bg-indigo-800/60 border border-indigo-700/50 text-slate-200 text-xs transition-all flex items-center justify-between gap-2 group"
                  >
                    <span>{sug}</span>
                    <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded group-hover:bg-indigo-500 group-hover:text-white shrink-0">
                      {isAr ? 'تطبيق' : 'Apply'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {profile.experiences.map((exp, idx) => (
            <div key={exp.id} className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-3 relative">
              <button
                onClick={() => removeExperience(exp.id)}
                className="absolute top-3 right-3 text-rose-400 hover:text-rose-300 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 transition-all"
                title={isAr ? 'حذف الخبرة' : 'Remove Experience'}
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
                <span>#{idx + 1} {isAr ? (exp.roleAr || 'خبرة مهنية جديدة') : (exp.roleEn || 'New Work Experience')}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'المسمى الوظيفي (إنجليزية)' : 'Role Title (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Operations Specialist"
                    value={exp.roleEn}
                    onChange={(e) => {
                      const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, roleEn: e.target.value } : x);
                      updateField('experiences', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'المسمى الوظيفي (عربية)' : 'Role Title (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: مسؤول تشغيل وتخطيط"
                    value={exp.roleAr}
                    onChange={(e) => {
                      const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, roleAr: e.target.value } : x);
                      updateField('experiences', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'المؤسسة/الشركة (إنجليزية)' : 'Company (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Acme Corporation"
                    value={exp.companyEn}
                    onChange={(e) => {
                      const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, companyEn: e.target.value } : x);
                      updateField('experiences', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'المؤسسة/الشركة (عربية)' : 'Company (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: شركة سوناطراك"
                    value={exp.companyAr}
                    onChange={(e) => {
                      const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, companyAr: e.target.value } : x);
                      updateField('experiences', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'تاريخ البداية والنهاية' : 'Period (Start - End)'}</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Start (e.g. 2021)"
                      value={exp.startDate}
                      onChange={(e) => {
                        const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, startDate: e.target.value } : x);
                        updateField('experiences', updated);
                      }}
                      className="w-1/2 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="End (e.g. Present)"
                      value={exp.endDate}
                      onChange={(e) => {
                        const updated = profile.experiences.map(x => x.id === exp.id ? { ...x, endDate: e.target.value } : x);
                        updateField('experiences', updated);
                      }}
                      className="w-1/2 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'الموقع/المدينة' : 'Location'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Oran, Algeria"
                    value={isAr ? exp.locationAr : exp.locationEn}
                    onChange={(e) => {
                      const updated = profile.experiences.map(x => x.id === exp.id ? { 
                        ...x, 
                        [isAr ? 'locationAr' : 'locationEn']: e.target.value 
                      } : x);
                      updateField('experiences', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir={isAr ? 'rtl' : 'ltr'}
                  />
                </div>
              </div>

              {/* Bullets List */}
              <div className="space-y-2 pt-2 border-t border-slate-700/40">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-semibold text-slate-300">
                    {isAr ? 'نقاط الإنجاز والمسؤوليات (Bullet Points):' : 'Bullet Points & Achievements:'}
                  </label>
                  <button
                    onClick={() => addExperienceBullet(exp.id)}
                    className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-indigo-300 text-[11px] font-medium flex items-center gap-1 transition-all"
                  >
                    <Plus className="w-3 h-3" />
                    <span>{isAr ? 'إضافة نقطة إنجاز' : 'Add Bullet'}</span>
                  </button>
                </div>

                {(isAr ? exp.bulletsAr : exp.bulletsEn).map((b, bIdx) => (
                  <div key={bIdx} className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder={isAr ? 'اكتب تفاصيل ومخرجات المهمة...' : 'Describe task or achievement...'}
                      value={b}
                      onChange={(e) => {
                        const newBullets = [...(isAr ? exp.bulletsAr : exp.bulletsEn)];
                        newBullets[bIdx] = e.target.value;
                        const updated = profile.experiences.map(x => x.id === exp.id ? {
                          ...x,
                          [isAr ? 'bulletsAr' : 'bulletsEn']: newBullets
                        } : x);
                        updateField('experiences', updated);
                      }}
                      className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                      dir={isAr ? 'rtl' : 'ltr'}
                    />

                    <button
                      onClick={() => handleEnhanceBullet(exp.id, bIdx, b, isAr ? exp.roleAr : exp.roleEn)}
                      disabled={enhancingBulletId === `${exp.id}-${bIdx}`}
                      className="px-2.5 py-1.5 rounded-lg bg-violet-600/30 hover:bg-violet-600 text-violet-200 border border-violet-500/40 text-[11px] font-medium flex items-center gap-1 shrink-0 transition-all"
                      title={isAr ? 'تحسين النقطة بالذكاء الاصطناعي مع أفعال إنجاز قوية' : 'Enhance with AI strong action verbs'}
                    >
                      {enhancingBulletId === `${exp.id}-${bIdx}` ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-300" />
                      ) : (
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      )}
                      <span>{isAr ? 'تحسين AI' : 'AI Enhance'}</span>
                    </button>

                    <button
                      onClick={() => removeExperienceBullet(exp.id, bIdx)}
                      className="p-1.5 text-rose-400 hover:text-rose-300 hover:bg-slate-800 rounded-lg transition-all"
                      title={isAr ? 'حذف هذه النقطة' : 'Delete bullet'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 4: Education */}
      {activeTab === 'education' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">
              {isAr ? 'المؤهلات والشهادات الجامعية' : 'Education & Academic Qualifications'}
            </span>
            <button
              onClick={addEducation}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة مؤهل تعليمي جديد' : 'Add New Education'}</span>
            </button>
          </div>

          {profile.education.map((edu, idx) => (
            <div key={edu.id} className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-3 relative">
              <button
                onClick={() => removeEducation(edu.id)}
                className="absolute top-3 right-3 text-rose-400 hover:text-rose-300 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 transition-all"
                title={isAr ? 'حذف هذا المؤهل' : 'Remove Education'}
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                <span>#{idx + 1} {isAr ? (edu.degreeAr || 'شهادة تعليمية جديدة') : (edu.degreeEn || 'New Degree Entry')}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الشهادة / التخصص (إنجليزية)' : 'Degree Title (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Master of Science in Computer Science"
                    value={edu.degreeEn}
                    onChange={(e) => {
                      const updated = profile.education.map(x => x.id === edu.id ? { ...x, degreeEn: e.target.value } : x);
                      updateField('education', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الشهادة / التخصص (عربية)' : 'Degree Title (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: ماستر في هندسة البرمجيات"
                    value={edu.degreeAr}
                    onChange={(e) => {
                      const updated = profile.education.map(x => x.id === edu.id ? { ...x, degreeAr: e.target.value } : x);
                      updateField('education', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'الجامعة / المعهد (إنجليزية)' : 'Institution (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. University of Oran 1"
                    value={edu.institutionEn}
                    onChange={(e) => {
                      const updated = profile.education.map(x => x.id === edu.id ? { ...x, institutionEn: e.target.value } : x);
                      updateField('education', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'الجامعة / المعهد (عربية)' : 'Institution (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: جامعة وهران 1 أحمد بن بلة"
                    value={edu.institutionAr}
                    onChange={(e) => {
                      const updated = profile.education.map(x => x.id === edu.id ? { ...x, institutionAr: e.target.value } : x);
                      updateField('education', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'تاريخ البداية والنهاية' : 'Dates (Start - End)'}</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Start (e.g. 2019)"
                      value={edu.startDate}
                      onChange={(e) => {
                        const updated = profile.education.map(x => x.id === edu.id ? { ...x, startDate: e.target.value } : x);
                        updateField('education', updated);
                      }}
                      className="w-1/2 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="End (e.g. 2023)"
                      value={edu.endDate}
                      onChange={(e) => {
                        const updated = profile.education.map(x => x.id === edu.id ? { ...x, endDate: e.target.value } : x);
                        updateField('education', updated);
                      }}
                      className="w-1/2 bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'التفاصيل أو التقدير (اختياري)' : 'Academic Details (Optional)'}</label>
                  <input
                    type="text"
                    placeholder={isAr ? 'تخصص متميز وملاحظات أكاديمية...' : 'Specialization & academic honors...'}
                    value={isAr ? (edu.detailsAr || '') : (edu.detailsEn || '')}
                    onChange={(e) => {
                      const updated = profile.education.map(x => x.id === edu.id ? { 
                        ...x, 
                        [isAr ? 'detailsAr' : 'detailsEn']: e.target.value 
                      } : x);
                      updateField('education', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir={isAr ? 'rtl' : 'ltr'}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 5: Skills */}
      {activeTab === 'skills' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">
              {isAr ? 'تصنيفات المهارات والكفاءات التقنية' : 'Skill categories & core competencies'}
            </span>
            <button
              onClick={addSkillCategory}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة فئة مهارات جديدة' : 'Add Skill Category'}</span>
            </button>
          </div>

          {profile.skillCategories.map((cat, idx) => (
            <div key={cat.id} className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-3 relative">
              <button
                onClick={() => removeSkillCategory(cat.id)}
                className="absolute top-3 right-3 text-rose-400 hover:text-rose-300 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 transition-all"
                title={isAr ? 'حذف هذه الفئة' : 'Remove Category'}
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <Wrench className="w-4 h-4 text-indigo-400" />
                <span>#{idx + 1} {isAr ? (cat.categoryAr || 'فئة جديدة') : (cat.categoryEn || 'New Category')}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الفئة (إنجليزية)' : 'Category Name (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Software Development & Architecture"
                    value={cat.categoryEn}
                    onChange={(e) => {
                      const updated = profile.skillCategories.map(x => x.id === cat.id ? { ...x, categoryEn: e.target.value } : x);
                      updateField('skillCategories', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الفئة (عربية)' : 'Category Name (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: تطوير البرمجيات والأنظمة"
                    value={cat.categoryAr}
                    onChange={(e) => {
                      const updated = profile.skillCategories.map(x => x.id === cat.id ? { ...x, categoryAr: e.target.value } : x);
                      updateField('skillCategories', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  {isAr ? 'قائمة المهارات بالإنجليزية (افصل بين كل مهارة بفاصلة ,):' : 'Skills List (English - comma separated):'}
                </label>
                <SkillTextInput
                  key={`skills-en-${cat.id}`}
                  skills={cat.skillsEn}
                  onChange={(skills) => {
                    const updated = profile.skillCategories.map(x => x.id === cat.id ? { ...x, skillsEn: skills } : x);
                    updateField('skillCategories', updated);
                  }}
                  placeholder="React, TypeScript, Node.js, SQL, Docker..."
                  dir="ltr"
                  separator=", "
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  {isAr ? 'قائمة المهارات بالعربية (افصل بين كل مهارة بفاصلة ،):' : 'Skills List (Arabic - comma separated):'}
                </label>
                <SkillTextInput
                  key={`skills-ar-${cat.id}`}
                  skills={cat.skillsAr}
                  onChange={(skills) => {
                    const updated = profile.skillCategories.map(x => x.id === cat.id ? { ...x, skillsAr: skills } : x);
                    updateField('skillCategories', updated);
                  }}
                  placeholder="تطوير الواجهات، إدارة البيانات، التحليل الإحصائي..."
                  dir="rtl"
                  separator="، "
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 6: Certifications */}
      {activeTab === 'certifications' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">
              {isAr ? 'الدورات التدريبية والشهادات المهنية' : 'Certifications & Training Courses'}
            </span>
            <button
              onClick={addCertification}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة شهادة / دورة جديدة' : 'Add Certification'}</span>
            </button>
          </div>

          {profile.certifications.map((cert, idx) => (
            <div key={cert.id} className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-3 relative">
              <button
                onClick={() => removeCertification(cert.id)}
                className="absolute top-3 right-3 text-rose-400 hover:text-rose-300 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 transition-all"
                title={isAr ? 'حذف هذه الشهادة' : 'Remove Certification'}
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-indigo-400" />
                <span>#{idx + 1} {isAr ? (cert.titleAr || 'شهادة تدريبية جديدة') : (cert.titleEn || 'New Certification Entry')}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الشهادة/الدورة (إنجليزية)' : 'Certification Title (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. AWS Certified Solutions Architect"
                    value={cert.titleEn}
                    onChange={(e) => {
                      const updated = profile.certifications.map(x => x.id === cert.id ? { ...x, titleEn: e.target.value } : x);
                      updateField('certifications', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم الشهادة/الدورة (عربية)' : 'Certification Title (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: شهادة احترافية في إدارة المشاريع"
                    value={cert.titleAr}
                    onChange={(e) => {
                      const updated = profile.certifications.map(x => x.id === cert.id ? { ...x, titleAr: e.target.value } : x);
                      updateField('certifications', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'الجهة المانحة/المعهد (إنجليزية)' : 'Issuer (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Project Management Institute"
                    value={cert.issuerEn}
                    onChange={(e) => {
                      const updated = profile.certifications.map(x => x.id === cert.id ? { ...x, issuerEn: e.target.value } : x);
                      updateField('certifications', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'الجهة المانحة/المعهد (عربية)' : 'Issuer (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: المعهد الوطني للتكوين المهني"
                    value={cert.issuerAr}
                    onChange={(e) => {
                      const updated = profile.certifications.map(x => x.id === cert.id ? { ...x, issuerAr: e.target.value } : x);
                      updateField('certifications', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'سنة الحصول عليها' : 'Year Obtained'}</label>
                  <input
                    type="text"
                    placeholder="e.g. 2023"
                    value={cert.year || ''}
                    onChange={(e) => {
                      const updated = profile.certifications.map(x => x.id === cert.id ? { ...x, year: e.target.value } : x);
                      updateField('certifications', updated);
                    }}
                    className="w-full md:w-1/2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 7: Languages */}
      {activeTab === 'languages' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-400">
              {isAr ? 'اللغات والمستويات' : 'Languages & Proficiency Levels'}
            </span>
            <button
              onClick={addLanguage}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAr ? 'إضافة لغة جديدة' : 'Add Language'}</span>
            </button>
          </div>

          {profile.languages.map((langItem, idx) => (
            <div key={idx} className="p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl space-y-3 relative">
              <button
                onClick={() => removeLanguage(idx)}
                className="absolute top-3 right-3 text-rose-400 hover:text-rose-300 p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 border border-slate-700 transition-all"
                title={isAr ? 'حذف هذه اللغة' : 'Remove Language'}
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="font-bold text-xs text-indigo-400 flex items-center gap-1.5">
                <LangIcon className="w-4 h-4 text-indigo-400" />
                <span>#{idx + 1} {isAr ? (langItem.languageAr || 'لغة جديدة') : (langItem.languageEn || 'New Language')}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم اللغة (إنجليزية)' : 'Language Name (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. English, Arabic, French..."
                    value={langItem.languageEn}
                    onChange={(e) => {
                      const updated = profile.languages.map((l, i) => i === idx ? { ...l, languageEn: e.target.value } : l);
                      updateField('languages', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'اسم اللغة (عربية)' : 'Language Name (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: اللغة العربية، الإنجليزية..."
                    value={langItem.languageAr}
                    onChange={(e) => {
                      const updated = profile.languages.map((l, i) => i === idx ? { ...l, languageAr: e.target.value } : l);
                      updateField('languages', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'مستوى الإتقان (إنجليزية)' : 'Proficiency Level (English)'}</label>
                  <input
                    type="text"
                    placeholder="e.g. Native / Professional Proficiency"
                    value={langItem.levelEn}
                    onChange={(e) => {
                      const updated = profile.languages.map((l, i) => i === idx ? { ...l, levelEn: e.target.value } : l);
                      updateField('languages', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-0.5">{isAr ? 'مستوى الإتقان (عربية)' : 'Proficiency Level (Arabic)'}</label>
                  <input
                    type="text"
                    placeholder="مثال: اللغة الأم / مستوى مهني متقدم"
                    value={langItem.levelAr}
                    onChange={(e) => {
                      const updated = profile.languages.map((l, i) => i === idx ? { ...l, levelAr: e.target.value } : l);
                      updateField('languages', updated);
                    }}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    dir="rtl"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
