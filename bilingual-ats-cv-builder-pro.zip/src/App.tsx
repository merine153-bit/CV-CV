import React, { useState, useMemo } from 'react';
import { initialProfile } from './data/initialProfile';
import { CandidateProfile, Language } from './types';
import { calculateAtsScore } from './utils/atsCalculator';
import { generateAndDownloadPdf, openPrintWindow } from './utils/pdfExport';
import { Navbar } from './components/Navbar';
import { PictureAdviceBanner } from './components/PictureAdviceBanner';
import { AtsScorePanel } from './components/AtsScorePanel';
import { CvPreview } from './components/CvPreview';
import { CvEditor } from './components/CvEditor';
import { AiJobTailorModal } from './components/AiJobTailorModal';
import { Sparkles, Edit3, Eye, FileText, CheckCircle, ShieldCheck } from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState<CandidateProfile>(initialProfile);
  const [lang, setLang] = useState<Language>('ar'); // Default to Arabic as requested
  const [showPhoto, setShowPhoto] = useState<boolean>(false); // Default to no-photo for 100% ATS score
  const [isTailorModalOpen, setIsTailorModalOpen] = useState<boolean>(false);
  const [activeViewMode, setActiveViewMode] = useState<'split' | 'edit' | 'preview'>('split');
  const [targetJobDescription, setTargetJobDescription] = useState<string>('');

  const isAr = lang === 'ar';

  // Recalculate ATS Score in real time based on active profile data & target job
  const atsAnalysis = useMemo(() => {
    return calculateAtsScore(profile, lang, targetJobDescription);
  }, [profile, lang, showPhoto, targetJobDescription]);

  const handleResetData = () => {
    if (window.confirm(isAr ? 'هل أنت تأكد من إعادة ضبط البيانات إلى السيرة الذاتية الأصلية؟' : 'Reset resume data to original default?')) {
      setProfile(initialProfile);
      setShowPhoto(false);
    }
  };

  const handleApplyTailoredSummary = (newSummary: string) => {
    if (!newSummary || !newSummary.trim()) return;
    setProfile(prev => ({
      ...prev,
      summaryAr: newSummary.trim(),
      summaryEn: newSummary.trim(),
    }));
  };

  const handleApplySkills = (skillsToAdd: string[]) => {
    const validSkills = (skillsToAdd || []).map(s => s.trim()).filter(Boolean);
    if (validSkills.length === 0) return;

    setProfile(prev => {
      const updatedCategories = [...prev.skillCategories];

      if (
        updatedCategories.length === 0 ||
        (!updatedCategories[0].categoryAr?.trim() && !updatedCategories[0].categoryEn?.trim() && (updatedCategories[0].skillsAr || []).filter(Boolean).length === 0)
      ) {
        const newCat = {
          id: updatedCategories[0]?.id || `cat-${Date.now()}`,
          categoryAr: 'المهارات المفتاحية والتقنية',
          categoryEn: 'Key Technical & Professional Skills',
          skillsAr: validSkills,
          skillsEn: validSkills,
        };
        return { ...prev, skillCategories: [newCat, ...updatedCategories.slice(1)] };
      }

      const firstCat = { ...updatedCategories[0] };
      if (!firstCat.categoryAr?.trim()) firstCat.categoryAr = 'المهارات المفتاحية والتقنية';
      if (!firstCat.categoryEn?.trim()) firstCat.categoryEn = 'Key Technical & Professional Skills';

      const existingAr = new Set((firstCat.skillsAr || []).map(s => s.trim()).filter(Boolean));
      const existingEn = new Set((firstCat.skillsEn || []).map(s => s.trim()).filter(Boolean));

      validSkills.forEach(s => {
        existingAr.add(s);
        existingEn.add(s);
      });

      firstCat.skillsAr = Array.from(existingAr);
      firstCat.skillsEn = Array.from(existingEn);

      updatedCategories[0] = firstCat;
      return { ...prev, skillCategories: updatedCategories };
    });
  };

  const handleApplyBullets = (bulletsToAdd: string[], targetRoleTitle?: string) => {
    const validBullets = (bulletsToAdd || []).map(b => b.trim()).filter(Boolean);
    if (validBullets.length === 0) return;

    setProfile(prev => {
      const updatedExp = [...prev.experiences];
      const isFirstEmpty = updatedExp.length > 0 &&
        !updatedExp[0].roleAr?.trim() &&
        !updatedExp[0].roleEn?.trim() &&
        !updatedExp[0].companyAr?.trim();

      if (updatedExp.length === 0 || isFirstEmpty) {
        const newExp = {
          id: updatedExp[0]?.id || `exp-${Date.now()}`,
          roleAr: targetRoleTitle || 'خبرة مهنية متخصصة',
          roleEn: targetRoleTitle || 'Targeted Professional Experience',
          companyAr: 'مؤسسة استراتيجية',
          companyEn: 'Key Enterprise',
          startDate: '2022',
          endDate: 'Present',
          locationAr: 'الجزائر',
          locationEn: 'Algeria',
          bulletsAr: validBullets,
          bulletsEn: validBullets,
        };
        return { ...prev, experiences: [newExp, ...updatedExp.slice(1)] };
      }

      const firstExp = { ...updatedExp[0] };
      if (!firstExp.roleAr?.trim()) firstExp.roleAr = targetRoleTitle || 'خبرة مهنية متخصصة';
      if (!firstExp.roleEn?.trim()) firstExp.roleEn = targetRoleTitle || 'Targeted Professional Experience';
      if (!firstExp.companyAr?.trim()) firstExp.companyAr = 'مؤسسة استراتيجية';
      if (!firstExp.companyEn?.trim()) firstExp.companyEn = 'Key Enterprise';

      const existingAr = new Set((firstExp.bulletsAr || []).map(b => b.trim()).filter(Boolean));
      const existingEn = new Set((firstExp.bulletsEn || []).map(b => b.trim()).filter(Boolean));

      validBullets.forEach(b => {
        existingAr.add(b);
        existingEn.add(b);
      });

      firstExp.bulletsAr = Array.from(existingAr);
      firstExp.bulletsEn = Array.from(existingEn);

      updatedExp[0] = firstExp;
      return { ...prev, experiences: updatedExp };
    });
  };

  const handleApplyAllTailored = (analysis: any) => {
    if (!analysis) return;
    if (analysis.suggestedSummary) {
      handleApplyTailoredSummary(analysis.suggestedSummary);
    }
    const skillsToApply = [
      ...(analysis.suggestedSkills || []),
      ...(analysis.missingKeywords || [])
    ];
    if (skillsToApply.length > 0) {
      handleApplySkills(skillsToApply);
    }
    if (analysis.suggestedBullets && analysis.suggestedBullets.length > 0) {
      handleApplyBullets(analysis.suggestedBullets, analysis.suggestedTitle);
    }
  };

  const handleGlobalPrint = () => {
    openPrintWindow('cv-printable-area', `CV ${isAr ? profile.fullNameAr : profile.fullNameEn}`);
  };

  const handleGlobalDownloadPdf = async () => {
    const name = isAr ? profile.fullNameAr.replace(/\s+/g, '_') : profile.fullNameEn.replace(/\s+/g, '_');
    const filename = `CV_${name}.pdf`;
    await generateAndDownloadPdf('cv-printable-area', filename);
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans ${isAr ? 'font-arabic' : ''}`}>
      {/* Navbar */}
      <Navbar
        lang={lang}
        onToggleLang={setLang}
        showPhoto={showPhoto}
        onTogglePhoto={setShowPhoto}
        onResetData={handleResetData}
        onPrint={handleGlobalPrint}
        onDownloadPdf={handleGlobalDownloadPdf}
      />

      {/* Sub-header / Quick Status */}
      <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2.5 print:hidden">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="font-semibold text-slate-300">
              {isAr ? 'الملف الشخصي المحمل:' : 'Active Profile:'}
            </span>
            <span className="text-emerald-400 font-bold">
              {(isAr ? profile.fullNameAr : profile.fullNameEn) || (isAr ? 'سيرة ذاتية جديدة' : 'New Resume')}
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">
              {(isAr ? profile.titleAr : profile.titleEn) || (isAr ? 'نموذج قابل للتعبئة' : 'Fillable Template')}
            </span>
          </div>

          {/* View Mode Toggle for Mobile / Small Screens */}
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700/60">
            <button
              onClick={() => setActiveViewMode('split')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                activeViewMode === 'split' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'عرض مزدوج' : 'Split View'}
            </button>

            <button
              onClick={() => setActiveViewMode('edit')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                activeViewMode === 'edit' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'المحرر فقط' : 'Editor Only'}
            </button>

            <button
              onClick={() => setActiveViewMode('preview')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                activeViewMode === 'preview' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'المعاينة والطباعة' : 'Preview & Print'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6 print:p-0 print:m-0 print:max-w-none print:w-full">
        {/* Dynamic Split / Layout Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start print:block print:w-full print:m-0 print:p-0">
          {/* Left Column: ATS Score Audit + Editor */}
          <div className={`space-y-6 lg:col-span-6 print:hidden ${activeViewMode === 'preview' ? 'hidden' : 'block'}`}>
            {/* ATS Live Audit Panel */}
            <div className="print:hidden">
              <AtsScorePanel
                analysis={atsAnalysis}
                lang={lang}
                onOpenTailorModal={() => setIsTailorModalOpen(true)}
              />
            </div>

            {/* Resume Editor */}
            <div className="print:hidden">
              <CvEditor
                profile={profile}
                onChangeProfile={setProfile}
                lang={lang}
              />
            </div>
          </div>

          {/* Right Column: Real-time CV Preview Sheet */}
          <div className={`lg:col-span-6 print:w-full print:m-0 print:p-0 ${activeViewMode === 'edit' ? 'hidden' : 'block'}`}>
            <div className="sticky top-20 print:static print:w-full print:m-0 print:p-0">
              <CvPreview
                profile={profile}
                lang={lang}
                showPhoto={showPhoto}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-6 mt-12 print:hidden">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-500 space-y-2">
          <p className="font-semibold text-slate-400">
            {isAr
              ? 'Bilingual ATS CV Builder Pro — أداة بناء وتطوير السيرة الذاتية متوافق مع كافة أنظمة ATS العالمية'
              : 'Bilingual ATS CV Builder Pro — Engineered for maximum Applicant Tracking System parser readability.'}
          </p>
          <p>
            {isAr
              ? 'مصممة بمرجعية خالية من أخطاء القراءة ومجهزة للتطابق مع إعلانات التوظيف في قطاعات البتروكيماويات والطب والتسيير'
              : 'Built with clean text-extraction logic, strong action verb metrics, and instant job tailoring via Gemini AI.'}
          </p>
          <div className="pt-2 border-t border-slate-800/80 max-w-xs mx-auto">
            <p className="text-sm font-semibold text-slate-300">
              {isAr ? 'صاحب التطبيق:' : 'App Owner:'}{' '}
              <span className="text-amber-400 font-bold tracking-wide">Merine Abdelillah</span>
            </p>
          </div>
        </div>
      </footer>

      {/* Target Job Tailor Modal */}
      <AiJobTailorModal
        isOpen={isTailorModalOpen}
        onClose={() => setIsTailorModalOpen(false)}
        lang={lang}
        profile={profile}
        targetJobDescription={targetJobDescription}
        onUpdateTargetJobDescription={setTargetJobDescription}
        onApplyTailoredSummary={handleApplyTailoredSummary}
        onApplySkills={handleApplySkills}
        onApplyBullets={handleApplyBullets}
        onApplyAllTailored={handleApplyAllTailored}
      />
    </div>
  );
}
